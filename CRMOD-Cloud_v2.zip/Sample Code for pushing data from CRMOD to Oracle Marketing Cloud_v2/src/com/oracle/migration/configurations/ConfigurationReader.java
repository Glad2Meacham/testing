///////////////////////////////////////////////////////////////////////////////
//
 //  Copyright (c) 2014, Oracle Corporation, All rights reserved.
 //
 //  FILE
 //    ConfigurationReader.java
 //
 ///////////////////////////////////////////////////////////////////////////////

package com.oracle.migration.configurations;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

import java.net.URLDecoder;

import java.util.Properties;


/**
 * Reads configuration from config.properties
 * @author rakraghu
 *
 */
public class ConfigurationReader
{

   private static Properties properties = new Properties ();
   private static String propFileName = "\\Config\\config.properties";

   /**
    * Reads configurations from config.properties file.
    */
   public static void loadConfigurations ()
   {

      try
      {
         properties.load (getStreamForExternalFolder (propFileName));
      }
      catch (Exception e)
      {
         throw new IllegalStateException ("Could not load configuration properties",e);
      }
   }

   /**
    * Returns the property value for the given key
    * @param key 
    * @return Property value
    */
   public static String getConfigurationProperty (String key)
   {
      return properties.getProperty (key);
   }

   /**
    * Returns InputStream for a file in external folder
    * @param fileName
    * @return
    *       InputStream for the file
    * @throws FileNotFoundException
    *          Thrown when file is not fount
    * @throws UnsupportedEncodingException
    *          Thrown if encoding format is not supported.
    */
   public static InputStream getStreamForExternalFolder (String fileName)
      throws FileNotFoundException, UnsupportedEncodingException
   {

      File jarPath = new File (ConfigurationReader.class.getProtectionDomain ().getCodeSource ().getLocation ().getPath ());
      String propertiesPath = jarPath.getParentFile ().getAbsolutePath ();

      FileInputStream stream = new FileInputStream (URLDecoder.decode (propertiesPath + fileName, "UTF-8"));

      return stream;
   }
}
