 ///////////////////////////////////////////////////////////////////////////////
 //
 //  Copyright (c) 2014, Oracle Corporation, All rights reserved.
 //
 //  FILE
 //    DataListSerializer.java
 //
 ///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.serializer;


import com.oracle.eloqua.entities.DataItemList;
import com.oracle.eloqua.entities.DataItems;

import java.io.IOException;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;


/**
 * Converts the List of DataItems to JSON format
 * <p>
 * [
 *    {
 *       "Key1":"value1",
 *       "Key2":"value2",
 *       "Key3":"value3"
 *    },
 *    {
 *       "Key1":"value1",
 *       "Key2":"value2",
 *       "Key3":"value3"
 *    }
 *  ]
 * @author rakraghu
 */
public class DataListSerializer
   extends JsonSerializer<DataItemList>
{

   @Override
   public void serialize (DataItemList dataList, JsonGenerator jgen, SerializerProvider arg2)
      throws IOException, JsonProcessingException
   {

      DataItems[] stdata = dataList.getDataItemList ();
      jgen.writeStartArray ();
      for (DataItems data : stdata)
      {

         jgen.writeObject (data);

      }
      jgen.writeEndArray ();
   }

}
