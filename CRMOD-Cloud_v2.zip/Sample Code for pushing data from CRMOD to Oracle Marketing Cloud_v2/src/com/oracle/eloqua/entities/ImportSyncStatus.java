///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    ImportSyncStatus.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author rakraghu
 */
public class ImportSyncStatus
   implements IEloquaEntity
{
   @JsonProperty ("syncEndedAt")
   private String syncendedat;

   public void setSyncendedat (String syncendedat)
   {
      this.syncendedat = syncendedat;
   }

   public String getSyncendedat ()
   {
      return syncendedat;
   }

   @JsonProperty ("uri")
   private String uri;

   public void setUri (String uri)
   {
      this.uri = uri;
   }

   public String getUri ()
   {
      return uri;
   }

   @JsonProperty ("syncStartedAt")
   private String syncstartedat;

   public void setSyncstartedat (String syncstartedat)
   {
      this.syncstartedat = syncstartedat;
   }

   public String getSyncstartedat ()
   {
      return syncstartedat;
   }

   @JsonProperty ("status")
   private String status;

   public void setStatus (String status)
   {
      this.status = status;
   }

   public String getStatus ()
   {
      return status;
   }

   @JsonProperty ("createdBy")
   private String createdby;

   public void setCreatedby (String createdby)
   {
      this.createdby = createdby;
   }

   public String getCreatedby ()
   {
      return createdby;
   }

   @JsonProperty ("syncedInstanceUri")
   private String syncedinstanceuri;

   public void setSyncedinstanceuri (String syncedinstanceuri)
   {
      this.syncedinstanceuri = syncedinstanceuri;
   }

   public String getSyncedinstanceuri ()
   {
      return syncedinstanceuri;
   }

   @JsonProperty ("createdAt")
   private String createdat;

   public void setCreatedat (String createdat)
   {
      this.createdat = createdat;
   }

   public String getCreatedat ()
   {
      return createdat;
   }
}
