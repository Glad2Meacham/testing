///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    LogItems.java
//
///////////////////////////////////////////////////////////////////////////////

package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author rakraghu
 */
public class LogItems
{
   @JsonProperty ("severity")
   private String severity;

   public void setSeverity (String severity)
   {
      this.severity = severity;
   }

   public String getSeverity ()
   {
      return severity;
   }

   @JsonProperty ("statusCode")
   private String statuscode;

   public void setStatuscode (String statuscode)
   {
      this.statuscode = statuscode;
   }

   public String getStatuscode ()
   {
      return statuscode;
   }

   @JsonProperty ("message")
   private String message;

   public void setMessage (String message)
   {
      this.message = message;
   }

   public String getMessage ()
   {
      return message;
   }

   @JsonProperty ("syncUri")
   private String syncuri;

   public void setSyncuri (String syncuri)
   {
      this.syncuri = syncuri;
   }

   public String getSyncuri ()
   {
      return syncuri;
   }

   @JsonProperty ("count")
   private Integer count;

   public void setCount (Integer count)
   {
      this.count = count;
   }

   public Integer getCount ()
   {
      return count;
   }

   @JsonProperty ("createdAt")
   private String createdat;

   public void setCreatedat (String createdat)
   {
      this.createdat = createdat;
   }

   public String getCreatedat ()
   {
      return createdat;
   }

}
