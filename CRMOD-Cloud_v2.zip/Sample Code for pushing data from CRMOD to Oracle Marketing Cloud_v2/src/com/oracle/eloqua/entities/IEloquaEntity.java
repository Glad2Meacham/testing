 ///////////////////////////////////////////////////////////////////////////////
 //
 //  Copyright (c) 2014, Oracle Corporation, All rights reserved.
 //
 //  FILE
 //    IEloquaEntity.java
 //
 ///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Master Interface for all Eloqua Entities.
 * @author rakraghu
 *
 */
@JsonSerialize (include = JsonSerialize.Inclusion.NON_NULL)
@JsonIgnoreProperties (ignoreUnknown = true)
public interface IEloquaEntity
{

}
