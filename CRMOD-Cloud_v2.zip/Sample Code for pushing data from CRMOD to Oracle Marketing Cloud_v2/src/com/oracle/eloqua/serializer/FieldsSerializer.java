///////////////////////////////////////////////////////////////////////////////
//
 //  Copyright (c) 2014, Oracle Corporation, All rights reserved.
 //
 //  FILE
 //    FieldSerializer.java
 //
 ///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.serializer;


import com.oracle.eloqua.entities.Fields;

import java.io.IOException;

import java.util.Map.Entry;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;


/**
 * Converts Field Object to JSON.
 * {
 *   "Key1":"value1",
 *   "Key2":"value2",
 *   "Key3":"value3"
 * }
 * @author rakraghu
 */
public class FieldsSerializer
   extends JsonSerializer<Fields>
{

   @Override
   public void serialize (Fields fieldMap, JsonGenerator jgen, SerializerProvider serializerProvider)
      throws IOException, JsonProcessingException
   {

      jgen.writeStartObject ();
      for (Entry<String, String> entry : fieldMap.getFieldMap ().entrySet ())
      {
         jgen.writeStringField (entry.getKey (), fieldMap.getFieldMap ().get (entry.getKey ()));

      }
      jgen.writeEndObject ();
   }
}
