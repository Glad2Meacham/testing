///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    ItemElement.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;


/**
 * @author rakraghu
 */
@JsonSerialize (include = JsonSerialize.Inclusion.NON_NULL)
public class ItemElement
   implements IEloquaEntity
{
   @JsonProperty ("hasReadOnlyConstraint")
   private Boolean hasreadonlyconstraint;

   @JsonProperty ("uri")
   private String uri;

   @JsonProperty ("defaultValue")
   private String defaultvalue;

   @JsonProperty ("statement")
   private String statement;

   @JsonProperty ("hasNotNullConstraint")
   private Boolean hasnotnullconstraint;

   @JsonProperty ("internalName")
   private String internalname;

   @JsonProperty ("dataType")
   private String datatype;

   @JsonProperty ("name")
   private String name;

   @JsonProperty ("hasUniquenessConstraint")
   private Boolean hasuniquenessconstraint;

   public String getDatatype ()
   {
      return datatype;
   }

   public String getDefaultvalue ()
   {
      return defaultvalue;
   }

   public Boolean getHasnotnullconstraint ()
   {
      return hasnotnullconstraint;
   }

   public Boolean getHasreadonlyconstraint ()
   {
      return hasreadonlyconstraint;
   }

   public Boolean getHasuniquenessconstraint ()
   {
      return hasuniquenessconstraint;
   }

   public String getInternalname ()
   {
      return internalname;
   }

   public String getName ()
   {
      return name;
   }

   public String getStatement ()
   {
      return statement;
   }

   public String getUri ()
   {
      return uri;
   }

   public void setDatatype (String datatype)
   {
      this.datatype = datatype;
   }

   public void setDefaultvalue (String defaultvalue)
   {
      this.defaultvalue = defaultvalue;
   }

   public void setHasnotnullconstraint (Boolean hasnotnullconstraint)
   {
      this.hasnotnullconstraint = hasnotnullconstraint;
   }

   public void setHasreadonlyconstraint (Boolean hasreadonlyconstraint)
   {
      this.hasreadonlyconstraint = hasreadonlyconstraint;
   }

   public void setHasuniquenessconstraint (Boolean hasuniquenessconstraint)
   {
      this.hasuniquenessconstraint = hasuniquenessconstraint;
   }

   public void setInternalname (String internalname)
   {
      this.internalname = internalname;
   }

   public void setName (String name)
   {
      this.name = name;
   }

   public void setStatement (String statement)
   {
      this.statement = statement;
   }

   public void setUri (String uri)
   {
      this.uri = uri;
   }

   @Override
   public String toString ()
   {
      return "ItemElement [hasreadonlyconstraint=" + hasreadonlyconstraint + ", uri=" + uri + ", defaultvalue=" + defaultvalue +
         ", statement=" + statement + ", hasnotnullconstraint=" + hasnotnullconstraint + ", internalname=" + internalname +
         ", datatype=" + datatype + ", name=" + name + ", hasuniquenessconstraint=" + hasuniquenessconstraint + "]";
   }

}
