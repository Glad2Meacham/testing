///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    RejectItems.java
//
///////////////////////////////////////////////////////////////////////////////

package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;

public class RejectItems
{
   @JsonProperty ("invalidFields")
   private String[] invalidfields;

   public void setInvalidfields (String[] invalidfields)
   {
      this.invalidfields = invalidfields;
   }

   public String[] getInvalidfields ()
   {
      return invalidfields;
   }

   @JsonProperty ("message")
   private String message;

   public void setMessage (String message)
   {
      this.message = message;
   }

   public String getMessage ()
   {
      return message;
   }

   @JsonProperty ("statusCode")
   private String statuscode;

   public void setStatuscode (String statuscode)
   {
      this.statuscode = statuscode;
   }

   public String getStatuscode ()
   {
      return statuscode;
   }

   @JsonProperty ("fieldValues")
   private FieldValues fieldvalues;

   public void setFieldvalues (FieldValues fieldvalues)
   {
      this.fieldvalues = fieldvalues;
   }

   public FieldValues getFieldvalues ()
   {
      return fieldvalues;
   }

   @JsonProperty ("recordIndex")
   private Integer recordindex;

   public void setRecordindex (Integer recordindex)
   {
      this.recordindex = recordindex;
   }

   public Integer getRecordindex ()
   {
      return recordindex;
   }

}
