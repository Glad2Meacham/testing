///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    MigrationLogger.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.logging;


import com.oracle.migration.Util.Util;
import com.oracle.migration.configurations.ConfigurationReader;

import com.oracle.migration.exceptions.MigrationException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.MissingResourceException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


/**
 * Common logger for logging exceptions while Migration.
 * @author rakraghu
 */
public class MigrationLogger
{

   private static Logger logger;

   

   private static enum LogLevel
   {
      Trace (Level.FINER),
      Debug (Level.FINE),
      Info (Level.INFO),
      Warn (Level.WARNING),
      Error (Level.SEVERE);

      private LogLevel (Level level)
      {
         m_level = level;
      }

      public Level getLevel ()
      {
         return m_level;
      }

      private final Level m_level;

   }


   /**
    * Returns the logger object.
    * @return
    *    Logger object.
    */
   public static Logger getLogger ()
   {
      if (null == logger)
      {
         logger = Logger.getLogger ("com.oracle.migration");
         setFileHandlerAndLogLevel ();
      }
      return logger;
   }

   /**
    * Creates a new File Handler and set the loglevel from the config file.
    */
   private static void setFileHandlerAndLogLevel ()
   {
      FileHandler handler = null;
      try
      {
         Date date = new Date ();
         String logDirPath = getLogDirPath();
         SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyyMMdd");
         handler =
               new FileHandler ( logDirPath +"\\log" + dateFormat.format (date) + "_" +
                                "%u%g.txt", 10485760, 10, true);
         Level level = getLogLevel ();
         handler.setLevel (level);
         handler.setFormatter (new SimpleFormatter ());
         logger.addHandler (handler);
         logger.setLevel (level);
         logger.setUseParentHandlers (false);
      }
      catch (Exception e)
      {
         throw new IllegalStateException("Error in creating logger",e);
      }


   }

   /**
    * Creates the log directory if not present. Returnrs the directory path if present.
    * @return
    *       Directory path
    * @throws MigrationException
    *       thrown if error occurs while getting parent path.
    */
   private static String getLogDirPath ()
      throws MigrationException
   {
      File file = new File ( Util.getParentPath () + "\\Logs");
      if (!file.exists ())
      {
         boolean bCreateDir = file.mkdir ();
         if (!bCreateDir)
         {
            throw new IllegalStateException ("Unable to create log directory");
         }

      }
      return file.getAbsolutePath ();
   }
   
   /**
    * Reads the LOGLEVEL parameter from config file and finds corresponding java.util.logging.Level
    * if the LOGLEVEL parameter is not set, Default parameter is Level.ALL
    * @return
    *       Loglevel
    */
   private static Level getLogLevel ()
   {
      String loglevel =
         ConfigurationReader.getConfigurationProperty ("LOGLEVEL");
      Level level = Level.ALL;
      for (LogLevel loglevel1 : LogLevel.values ())
      {

         if (loglevel1.toString ().equalsIgnoreCase (loglevel))
         {
            level = loglevel1.getLevel ();
            break;
         }
      }
      return level;
   }

}
