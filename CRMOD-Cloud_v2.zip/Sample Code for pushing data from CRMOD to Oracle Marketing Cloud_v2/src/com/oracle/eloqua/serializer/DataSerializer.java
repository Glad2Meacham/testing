
 ///////////////////////////////////////////////////////////////////////////////
 //
 //  Copyright (c) 2014, Oracle Corporation, All rights reserved.
 //
 //  FILE
 //    DataSerializer.java
 //
 ///////////////////////////////////////////////////////////////////////////////
 package com.oracle.eloqua.serializer;


import com.oracle.eloqua.entities.DataItems;

import java.io.IOException;

import java.util.Map.Entry;

import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.JsonSerializer;
import org.codehaus.jackson.map.SerializerProvider;


/**
 * Converts DataItem Object to JSON Format
 * {
 *   "Key1":"value1",
 *   "Key2":"value2",
 *   "Key3":"value3"
 * }
 * @author rakraghu
 */
public class DataSerializer
   extends JsonSerializer<DataItems>
{

   @Override
   public void serialize (DataItems data, JsonGenerator jgen, SerializerProvider arg2)
      throws IOException, JsonProcessingException
   {
      jgen.writeStartObject ();
      for (Entry<String, String> entry : data.getDataItem ().entrySet ())
      {
         jgen.writeStringField (entry.getKey (), data.getDataItem ().get (entry.getKey ()));

      }
      jgen.writeEndObject ();

   }

}
