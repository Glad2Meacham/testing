///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    FieldDetails.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import java.util.Arrays;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author rakraghu
 */
public class FieldDetails
   implements IEloquaEntity
{
   @JsonProperty ("offset")
   private Integer offset;

   @JsonProperty ("hasMore")
   private Boolean hasmore;

   @JsonProperty ("limit")
   private Integer limit;

   @JsonProperty ("totalResults")
   private Integer totalresults;

   @JsonProperty ("count")
   private Integer count;

   @JsonProperty ("items")
   private ItemElement[] items;

   public Integer getCount ()
   {
      return count;
   }

   public Boolean getHasmore ()
   {
      return hasmore;
   }

   public ItemElement[] getItems ()
   {
      return items;
   }

   public Integer getLimit ()
   {
      return limit;
   }

   public Integer getOffset ()
   {
      return offset;
   }

   public Integer getTotalresults ()
   {
      return totalresults;
   }

   public void setCount (Integer count)
   {
      this.count = count;
   }

   public void setHasmore (Boolean hasmore)
   {
      this.hasmore = hasmore;
   }

   public void setItems (ItemElement[] items)
   {
      this.items = items;
   }

   public void setLimit (Integer limit)
   {
      this.limit = limit;
   }

   public void setOffset (Integer offset)
   {
      this.offset = offset;
   }

   public void setTotalresults (Integer totalresults)
   {
      this.totalresults = totalresults;
   }

   @Override
   public String toString ()
   {
      return "FieldDetails [offset=" + offset + ", hasmore=" + hasmore +
         ", limit=" + limit + ", totalresults=" + totalresults + ", count=" +
         count + ", items=" + Arrays.toString (items) + "]";
   }

}
