
 ///////////////////////////////////////////////////////////////////////////////
 //
 //  Copyright (c) 2014, Oracle Corporation, All rights reserved.
 //
 //  FILE
 //    FieldDeserialzer.java
 //
 ///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.serializer;


import com.oracle.eloqua.entities.Fields;

import java.io.IOException;

import java.util.Iterator;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;


/**
 * Converts Fields JSON to Fields Object
 * @author rakraghu
 */
public class FieldsDeserialzer
   extends JsonDeserializer<Fields>
{

   @Override
   public Fields deserialize (JsonParser parser, DeserializationContext context)
      throws IOException, JsonProcessingException
   {
      JsonNode node = parser.getCodec ().readTree (parser);
      Fields fields = new Fields ();
      for (Iterator<String> iterator = node.getFieldNames (); iterator.hasNext (); )
      {
         String type = iterator.next ();
         fields.setField (type, node.get (type).getTextValue ());
      }
      return fields;
   }
}
