///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    Util.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.Util;


import com.oracle.migration.exceptions.MigrationException;

import java.io.File;
import java.io.UnsupportedEncodingException;

import java.net.URLDecoder;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * Holds the utility methods used across classes
 * @author rakraghu
 */
public class Util
{
   /**
    * Generates datetime appended name for object specified to be assigned while
    * internally generating data files.
    * 
    * @param sObjName Name of the object
    * @return datetime appended name for object
    */
   public static String generateFileName (String sObjName)
   {
      Date date = new Date ();
      SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyyMMddHHmmss");
      String fileName = sObjName.replaceAll (" ", "_") + "_" + dateFormat.format (date);
      return fileName;
   }

   /**
    * Return the parent path
    * @return
    *      parent path
    * @throws MigrationException
    *      Thrown if the decoding of parent path fails.
    */     
   public static String getParentPath()
      throws MigrationException
   {
      File jarPath = new File (Util.class.getProtectionDomain ().getCodeSource ().getLocation ().getPath ());
      try
      {
         return URLDecoder.decode(jarPath.getParentFile ().getAbsolutePath (),"UTF-8");
      }
      catch (UnsupportedEncodingException e)
      {
         throw new MigrationException("Error in finding parent path");
      }
   }

   /**
    * Splits the given string in to list of values using the delimiter character
    * specified by user. This method will skip delimiter present with in each
    * data value if present.
    * 
    * @param sInput input string to be split
    * @param cDeLim delimiter to use while splitting data
    * @return
    *    Return List of Strings
    */
   public static List<StringBuilder> split (String sInput, char cDeLim)
   {
      List<StringBuilder> string = new ArrayList<StringBuilder> ();
      while (true)
      {
         StringBuilder s1 = getToken (sInput, cDeLim);
         string.add (s1);
         if (s1.length () != sInput.length ())
         {
            sInput = sInput.substring (s1.length () + 1);
         }
         else
         {
            break;
         }

      }
      return string;
   }

   /**
    * Used by split functionality to fetch each valid data value seperated by 
    * delimiter 
    * 
    * @param sInput input string to process
    * @param cDeLim delimiter for data
    * @return each valid data value seperated by delimiter in given string
    */
   private static StringBuilder getToken (String sInput, char cDeLim)
   {
      StringBuilder sbNewString = new StringBuilder ();

      boolean bStrictQuote = true;
      char[] strArray = sInput.toCharArray ();
      char c;
      for (int index = 0; index < strArray.length; index++)
      {
         c = strArray[index];
         if (c == '"')
         {
            bStrictQuote = !bStrictQuote;

         }
         else if (c == cDeLim && bStrictQuote)
         {
            return sbNewString;
         }
         sbNewString.append (c);

      }
      return sbNewString;

   }
}
