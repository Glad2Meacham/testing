///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    SendDataToEloqua.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.migrate;


import com.oracle.crmod.FetchDataFromCRMOD;
import com.oracle.eloqua.entities.CustomObjectList;
import com.oracle.eloqua.entities.CustomObjectitemElement;
import com.oracle.eloqua.entities.DataItemList;
import com.oracle.eloqua.entities.DataItems;
import com.oracle.eloqua.entities.DataResponse;
import com.oracle.eloqua.entities.FieldDetails;
import com.oracle.eloqua.entities.Fields;
import com.oracle.eloqua.entities.ImportDefinition;
import com.oracle.eloqua.entities.ImportLogs;
import com.oracle.eloqua.entities.ImportSyncStatus;
import com.oracle.eloqua.entities.ItemElement;
import com.oracle.eloqua.entities.RejectReason;
import com.oracle.eloqua.httpClient.EloquaBulkRestClient;
import com.oracle.migration.Util.CommandLineUtil;
import com.oracle.migration.Util.Constants;
import com.oracle.migration.configurations.ConfigurationReader;
import com.oracle.migration.exceptions.MigrationException;
import com.oracle.migration.logging.MigrationLogger;
import com.oracle.migration.mapping.FieldMappingDef;
import com.oracle.migration.mapping.MappingParser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;


/**
 * Reads Eloqua Custom Object Fields, Creates Import defintion
 * initiates data fetch from CRMOD, Sends data to eloqua in specified chunks
 * and Checks whether the import status is success and logs the failure scenarios.
 * @author rakraghu
 **/
public class SendDataToEloqua
{
   private static final String s_customObjectsPath = "customObjects";
   private static final String s_EloquaCOFieldDetailsPath = "{customObjectURL}/fields";
   private static final String s_EloquaCOImportDefPath = "{customObjectURL}/imports";

   private String m_sEloquaCOImportDataURI;
   private FieldMappingDef m_fieldMappingDef;
   private final EloquaBulkRestClient m_client;
   private CustomObjectList m_CustomObjectList;
   private Map<String, ItemElement> m_EloquaFieldDetailsMap;
   private List<String> fieldSetToImport = new ArrayList<String> ();
   private String m_sEloquaCustomObjectURI;
   private String m_sEloquaObjectName;
   private ArrayList<ImportSyncStatus> arlImportSyncStatus;
   private final Logger m_logger = MigrationLogger.getLogger ();


   private final static HashMap<String, String> s_QueryParam;
   static
   {
      s_QueryParam = new HashMap<String, String> ();
      s_QueryParam.put ("format", "json");
   }


   /**
    * Constructor accepts username and password
    * @param userName eloqua UserName
    * @param password eloqua password
    * @throws MigrationException
    *          thrown while contacting Eloqua
    */
   public SendDataToEloqua (String userName, String password)
      throws MigrationException
   {
      m_client = new EloquaBulkRestClient (ConfigurationReader.getConfigurationProperty (Constants.s_ELOQURL), userName, password);
   }

   /**
    * Reads Eloqua Custom Object Fields, Creates Import defintion
    * initiates data fetch from CRMOD, Sends data to eloqua in specified chunks
    * and Checks whether the import status is success and logs the failure scenarios.
    * @throws MigrationException
    *          Thrown while contacting eloqua and CRMOD.
    */
   public void process ()
      throws MigrationException
   {

      String sMappingFile = CommandLineUtil.getArgumentValue (Constants.s_MAPPINGFILE);
      if (null == sMappingFile)
      {
         throw new IllegalStateException ("Mapping file is a required field");
      }

      m_fieldMappingDef = MappingParser.createFieldmappingDef (sMappingFile);
      m_sEloquaObjectName = m_fieldMappingDef.getTargetObjectName ();
      List<DataItemList> dataItemLists = createDataItemList ();
      if(dataItemLists.isEmpty ())
      {
         throw new MigrationException("Fectched zero records from CRMOD.");
      }
      fetchCustomObjectListFromEloqua ();
      arlImportSyncStatus = new ArrayList<ImportSyncStatus> ();
      getEloquaObjectDetails ();
      fetchFieldDetailsForEloquaCustomObject ();
      createImportDefiniton ();
      if (null != dataItemLists && !dataItemLists.isEmpty ())
      {
         for (DataItemList dataItemList : dataItemLists)
         {
            DataResponse dataresponse =
               m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.POST,
                                             m_sEloquaCOImportDataURI + "/data", dataItemList, DataResponse.class, null, null);
            ImportSyncStatus importSysncStatus = getImportStatus (dataresponse.getUri ());
            if ("active".equalsIgnoreCase (importSysncStatus.getStatus ()))
            {
               arlImportSyncStatus.add (importSysncStatus);
            }

            checkImportStatus ();
         }
         while (!arlImportSyncStatus.isEmpty ())
         {
            try
            {
               Thread.sleep (60000);
            }
            catch (InterruptedException ex)
            {
               Thread.currentThread ().interrupt ();
            }
            checkImportStatus ();
         }
      }
   }

   /**
    * Checks whether import is success or failure.
    * @throws MigrationException
    *        thrown while contacting Eloqua.
    */
   private void checkImportStatus ()
      throws MigrationException
   {
      for (int index = 0; index < arlImportSyncStatus.size (); index++)
      {
         ImportSyncStatus status = arlImportSyncStatus.get (index);
         ImportSyncStatus refreshedStatus = getImportStatus (status.getUri ());
         String statusMsg = refreshedStatus.getStatus ();
         if ("success".equalsIgnoreCase (statusMsg))
         {
            arlImportSyncStatus.remove (status);
            continue;
         }
         if (("warning".equalsIgnoreCase (statusMsg))||("error".equalsIgnoreCase (statusMsg)))
         {
            handleImportFailure (refreshedStatus);
            break;
         }
      }


   }

   public static void main (String[] args)
   {

      SendDataToEloqua eloqua = null;
      try
      {
         ConfigurationReader.loadConfigurations ();
         CommandLineUtil.processCommandLineArgs (args);
         String userName = CommandLineUtil.getArgumentValue (Constants.s_ELOQ_USRNAME);
         String password = CommandLineUtil.getArgumentValue (Constants.s_ELOQ_PASSWD);
         eloqua = new SendDataToEloqua (userName, password);
         eloqua.process ();
      }
      catch (MigrationException exception)
      {
         eloqua.m_logger.log (Level.SEVERE, "Error in Migrating Data to Eloqua", exception);
      }
      finally
      {
         if (null != eloqua && null != eloqua.m_client)
         {
            eloqua.m_client.close ();
         }

      }
   }

   /**
    * Fetch List of Custom Objects from Eloqua.
    * @throws MigrationException
    *         thrown while contacting Eloqua.
    */
   private void fetchCustomObjectListFromEloqua ()
      throws MigrationException
   {

      m_CustomObjectList =
            m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, s_customObjectsPath,
                                          null, CustomObjectList.class, null, s_QueryParam);

   }

   /**
    * Fetch Field Details for a particular custom Object froon Eloqua.
    * @throws MigrationException
    *         thrown while contacting Eloqua.
    */
   private void fetchFieldDetailsForEloquaCustomObject ()
      throws MigrationException
   {
      HashMap<String, Object> pathResolver = new HashMap<String, Object> ();
      pathResolver.put ("customObjectURL", m_sEloquaCustomObjectURI);

      FieldDetails fldDetails =
         m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, s_EloquaCOFieldDetailsPath,
                                       null, FieldDetails.class, pathResolver, s_QueryParam);
      m_EloquaFieldDetailsMap = new HashMap<String, ItemElement> ();
      for (ItemElement field : fldDetails.getItems ())
      {
         m_EloquaFieldDetailsMap.put (field.getInternalname (), field);
      }
   }


   /**
    * Find the the desired custom Object from list of Custom Objects and assigns the object URI
    */
   private void getEloquaObjectDetails ()
   {
      CustomObjectitemElement desiredItem = null;
      for (CustomObjectitemElement item : m_CustomObjectList.getCustomobjectitems ())
      {
         if (m_sEloquaObjectName.equals (item.getName ()))
         {
            desiredItem = item;
            break;
         }


      }
      m_sEloquaCustomObjectURI = desiredItem.getUri ();
   }


   /**
    * Creates an Import definition
    * @return
    *       ImportDefinition Object
    * @throws MigrationException
    *       thrown while contacting Eloqua.
    */
   private ImportDefinition createImportDefiniton ()
      throws MigrationException
   {
      HashMap<String, Object> pathResolver = new HashMap<String, Object> ();
      pathResolver.put ("customObjectURL", m_sEloquaCustomObjectURI);
      ImportDefinition definition = new ImportDefinition ();
      definition.setName (m_sEloquaObjectName);
      Fields field = new Fields ();
      for (String internalFieldName : fieldSetToImport)
      {
         ItemElement itemField = m_EloquaFieldDetailsMap.get (internalFieldName);
         if (null == itemField)
         {
            throw new MigrationException (internalFieldName + "not a valid field in Eloqua");
         }
         field.setField (itemField.getInternalname (), itemField.getStatement ());
         if (itemField.getHasuniquenessconstraint ())
         {
            definition.setIdentifierfieldname (itemField.getInternalname ());
         }

      }
      definition.setFields (field);
      definition.setIssynctriggeredonimport ("true");
      definition =
            m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.POST, s_EloquaCOImportDefPath,
                                          definition, ImportDefinition.class, pathResolver, null);
      m_sEloquaCOImportDataURI = definition.getUri ();
      return definition;
   }


   /**
    * Creates a list of DataItems to be send to Eloqua
    * @throws MigrationException
    *        thrown while fetching data from CRMOD
    */
   private List<DataItemList> createDataItemList ()
      throws MigrationException
   {
      List<String> valueList = new ArrayList<String> ();
      List<String> currentList = new ArrayList<String> ();
      List<DataItemList> lstDataItemList = new ArrayList<DataItemList> ();
      String fileName = CommandLineUtil.getArgumentValue (Constants.s_CSVFILENAME);
      valueList = new FetchDataFromCRMOD ().fetchData (m_fieldMappingDef, fileName);
      if (valueList.size () > 1)
      {
         int headerSize = Integer.valueOf (valueList.get (0));
         fieldSetToImport = valueList.subList (1, headerSize + 1);
         valueList = valueList.subList (headerSize + 1, valueList.size ());
         DataItems dataItem = new DataItems ();
         int numTries = 0;
         int split = 1000;
         int numRows = Integer.valueOf (valueList.get (valueList.size () - 1));
         String chunkSize = ConfigurationReader.getConfigurationProperty (Constants.s_CHUNKSIZE);
         if (null != chunkSize)
         {
            split = Integer.valueOf (chunkSize);
         }
         m_logger.log (Level.INFO, "Data chunk size is:" + split);
         int i;
         for (i = 0; i < numRows / split; i++)
         {
            currentList = valueList.subList (i * split * headerSize, ((i + 1) * split * headerSize));
            lstDataItemList.add (formDataItemList (dataItem, currentList, headerSize));
         }
         if (numTries < numRows % split)
         {
            currentList = valueList.subList (i * split * headerSize, valueList.size () - 1);
            lstDataItemList.add (formDataItemList (dataItem, currentList, headerSize));
         }
      }
      return lstDataItemList;
   }

   /**
    * Form DataItemList based on Chunk Size
    * @param dataItem
    *         Data Item OBject
    * @param currentList
    *         List based on ChunkSize
    * @param headerSize
    *         No of headers mapped
    * @return DataListItem 
    *       Contains list of Data Item.
    */
   private DataItemList formDataItemList(DataItems dataItem,List<String> currentList, int headerSize)
   { int head=0;
     DataItemList dataItemList = new DataItemList ();
      for (int index = 0; index < currentList.size (); index++)
      {
         dataItem.putDataItem (fieldSetToImport.get (head), currentList.get (index));
         if (head == headerSize - 1)
         {
            dataItemList.addDataItem (dataItem);
            dataItem = new DataItems ();
            head = 0;
         }
         else
         {
            head++;
         }
      }
      return dataItemList;
   }
   /**
    * Queries eloqua for the import status.
    * @param uri Import URL
    * @return
    *       Returns the Import Status
    * @throws MigrationException
    *        thrown while contacting Eloqua.
    */
   private ImportSyncStatus getImportStatus (String uri)
      throws MigrationException
   {
      return m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, uri, null,
                                           ImportSyncStatus.class, null, s_QueryParam);
   }

   /**
    * Logs if the import status is error or warning.
    * @param importSyncStatus 
    *        ImportStatus to be logged
    * @throws MigrationException
    *       thrown while contacting Eloqua.
    */
   private void handleImportFailure (ImportSyncStatus importSyncStatus)
      throws MigrationException
   {
      RejectReason reason =
         m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, importSyncStatus.getUri () +
                                       "/rejects", null, RejectReason.class, null, s_QueryParam);
      ImportLogs logs =
         m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, importSyncStatus.getUri () +
                                       "/logs", null, ImportLogs.class, null, s_QueryParam);

      ObjectMapper mapper = new ObjectMapper ();
      mapper.enable (SerializationConfig.Feature.INDENT_OUTPUT);
      try
      {
         m_logger.log (Level.SEVERE, "Import Failed \n Reject Reason = [" + mapper.writeValueAsString (reason));
         m_logger.log (Level.SEVERE, "Import Failed \n Logs from Eloqua  = [" + mapper.writeValueAsString (logs));
      }
      catch (Exception e)
      {
         throw new MigrationException ("Error while writing import failure logs", e);
      }
   }

   /**
    * Returns Http Client object
    * @return
    *      EloquaBulkRestClient Object 
    */
   public EloquaBulkRestClient getClient ()
   {
      return m_client;
   }
}
