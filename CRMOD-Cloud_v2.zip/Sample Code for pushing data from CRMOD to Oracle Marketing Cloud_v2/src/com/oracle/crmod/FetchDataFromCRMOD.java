///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    FetchDataFromCRMOD.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.crmod;


import com.oracle.migration.Util.CommandLineUtil;
import com.oracle.migration.Util.Constants;
import com.oracle.migration.Util.Util;
import com.oracle.migration.configurations.ConfigurationReader;
import com.oracle.migration.exceptions.MigrationException;
import com.oracle.migration.logging.MigrationLogger;
import com.oracle.migration.mapping.FieldMapping;
import com.oracle.migration.mapping.FieldMappingDef;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;

import java.nio.charset.Charset;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.bind.DatatypeConverter;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;


/**
 * Invokes the SOAP connection, prepares the input WSDL and callsthe Export,
 * Monitor and Retrieve web service APIs to retrieves the data as zip with
 * CSV and export summary.Alternatively, a CSVfile can be provided as input
 * and in that case web service calls will be skipped. In both scenarios the
 * processes the CSV and returns as result a list with number of headers,
 * header values,data values, number of rows in that order respectively.
 *
 * @author      spalasse
 */
public class FetchDataFromCRMOD
{
   Map<String, String> m_xmlArgs = new HashMap<String, String> ();

   // wsdl file location string constants
   private static final String s_EXPORT_WSDL_LOCATION = "WSDL/export_web_service_input.xml";
   private static final String s_MONITOR_WSDL_LOCATION = "WSDL/monitor_web_service_input.xml";
   private static final String s_RETRIEVE_WSDL_LOCATION = "WSDL/retreive_web_service_input.xml";

   // soap action string constants
   private static final String s_EXPORT_SOAP_ACTION =
      "document/urn:crmondemand/ws/exportwebservice/:ExportWebServiceCreateExportRequest";
   private static final String s_MONITOR_SOAP_ACTION =
      "document/urn:crmondemand/ws/exportwebservice/:ExportWebServiceMonitorExportRequest";
   private static final String s_RETRIEVE_SOAP_ACTION =
      "document/urn:crmondemand/ws/exportwebservice/:ExportWebServiceRetrieveExportAttachment";

   private final Logger m_logger = MigrationLogger.getLogger ();
   private String m_sObjectName;


   /**
    * Calls the export, Monitor and Retrieve web services sequentially to 
    * fetch data from CRM OD or accepts the data as CSV from user in case the
    * export is done manually, essentially for large chunk of data. Data as CSV 
    * will be processed into the required list format based on user-provided
    * mapping file.
    * 
    * @param fieldMappingDef     Mapping between field's CRM display name and
    *                            ELOQUA internal name generated using user-
    *                            provided mapping XML
    * @param sFileName            CSV file name if data export has been done
    *                            manually and the file is available in the
    *                            "DataFiles" folder
    * @return                    Processed data as a list with format{number of
    *                            headers, header values, data values, number of
    *                            rows processed}
    * @throws MigrationException If an error occurs while connecting or fetching
    *                            data from CRM OD application
    */
   public List<String> fetchData (FieldMappingDef fieldMappingDef, String sFileName)
      throws MigrationException
   {
      String sAttachmentId = null;
      String sAttachmentResponse = null;
      String sResponse = null;
      String sRequestId = null;
      SoapClient soapClient = null;
      List<String> dataList = new ArrayList<String> ();
      ConfigurationReader.loadConfigurations ();
      String sUrl = ConfigurationReader.getConfigurationProperty (Constants.s_CRMODURL);
      if (null == sUrl || sUrl.length () == 0)
      {
         throw new IllegalStateException ("Required field CRMOD URL cannot be blank");
      }
      soapClient = new SoapClient (sUrl + "/Services/Integration");
      if (fieldMappingDef != null)
      {
         m_sObjectName = fieldMappingDef.getSourceObjectName ();
      }
      if (null == m_sObjectName)
      {
         throw new IllegalStateException ("Sourcs Object name cannot be blank.");
      }

      //Call the webservices in order and fetch data as CSV param is empty
      if (sFileName == null)
      {
         prepareExportXMLBindings ();
         m_xmlArgs.put (Constants.s_OBJ_NAME, m_sObjectName);

         m_logger.log (Level.INFO, "Export request sent");

         //call Export webservice
         sResponse = soapClient.sendRequestAndFetchData (s_EXPORT_WSDL_LOCATION, s_EXPORT_SOAP_ACTION, m_xmlArgs);

         if (sResponse == null)
         {
            throw new MigrationException ("Export webservice call failed");
         }
         else
         {
            sRequestId = extractFieldDataFromResponse (sResponse, "RequestId");
            if (sRequestId == null)
            {
               String sErrMsg = extractFieldDataFromResponse (sResponse, "errormsg");
               if (sErrMsg != null)
               {
                  throw new MigrationException ("Fetch data from CRM failed while calling Export webservice \n" +
                     "Web service response error is: " + sErrMsg);
               }
               else
               {
                 throw new MigrationException ("Fetch data from CRM failed while calling Export webservice: \n" +
                    "Export web service returned invalid Request Id ");
               }
            }

            m_logger.log (Level.INFO, "Export request completed. Request id is: " + sRequestId);
            m_xmlArgs.clear ();
            addUsernameAndPasswdToXMLArgs ();
            m_xmlArgs.put ("reqId", sRequestId);

            //call Monitor web service
            sResponse = monitorExportCompletion (soapClient);

            if (sResponse == null)
            {
               throw new MigrationException ("Export status check failed: Status Monitor service returned invalid response");
            }

            sAttachmentId = extractFieldDataFromResponse (sResponse, "FileId");
            if (sAttachmentId == null)
            {
               throw new MigrationException ("Failed to retreive attachment: Attachment ID  is null");
            }

            m_xmlArgs.put ("attId", sAttachmentId);

            m_logger.log (Level.INFO, "Trying to extract attachment with Id: " + sAttachmentId);

            //call Retrieve web service
            sResponse = soapClient.sendRequestAndFetchData (s_RETRIEVE_WSDL_LOCATION, s_RETRIEVE_SOAP_ACTION, m_xmlArgs);

            if (sResponse == null)
            {
               throw new MigrationException ("Attachment Retrieval service returned invalid response: Failed to retrieve attachment with id :" + sAttachmentId);
            }

            sAttachmentResponse = extractFieldDataFromResponse (sResponse, "Attachment");
            if (sAttachmentResponse == null)
            {
               throw new MigrationException ("Failed to retreive attachment as zip");
            }

            sFileName = extractCSVFileNameFromResponse (sAttachmentResponse);
            if (null == sFileName)
            {
               throw new MigrationException ("Data export has returned zero records. Verify export summary");
            }

         }
      }
      else
      {
         sFileName = Util.getParentPath ()+"\\DataFiles\\" + sFileName;
      }
      if (null != sFileName)
      {
         m_logger.log (Level.INFO, "Reading csv: " + sFileName);
         String sDeLim = CommandLineUtil.getArgumentValue (Constants.s_DELIMITER);
         char cDeLim;
         if (null != sDeLim && sDeLim.contains (";"))
         {
            cDeLim = ';';
         }
         else
         {
            cDeLim = ',';
         }

         dataList = processCSVFileUsingFieldMapping (fieldMappingDef, sFileName, cDeLim);

         if (null != dataList)
         {
            m_logger.log (Level.INFO, "Reading csv: " + sFileName + " completed successfully");
         }
      }
      return dataList;
   }

   /**
    * Calls the Monitor webservce an polls export request staus for completion.
    * Makes the current thread wait for 3 minutes and 1 minute each later till 
    * total wait time is 10 minutes or the export request completes, whichever
    * happens earlier. The output if request completed successfully will contain
    * the attachment file Id to be processed for data
    *
    * @param soapClient          Instance of SOAP client connection
    * @return                    Response from Monitor web service as string. If
    *                            invocation is success, attachment Id will be
    *                            present in the response else the error message
    * @throws MigrationException If an error occurs while connecting or fetching
    *                            data from CRM OD application
    */
   private String monitorExportCompletion (SoapClient soapClient)
      throws MigrationException
   {
      String sResponse;
      String sStatus = null;
      int numTries = 0;
      int time = 180000;
      do
      {
         try
         {
            m_logger.log (Level.INFO, "Waiting for export to complete. Monitoring the status");
            Thread.sleep (time);
            time = 60000;
            numTries++;
         }
         catch (InterruptedException ex)
         {
            Thread.currentThread ().interrupt ();
         }

         sResponse = soapClient.sendRequestAndFetchData (s_MONITOR_WSDL_LOCATION, s_MONITOR_SOAP_ACTION, m_xmlArgs);
         if (sResponse == null)
         {
            throw new MigrationException("Fetching export status using Monitor service API failed");
         }
         else
         {
            sStatus = extractFieldDataFromResponse (sResponse, "Status");
            if (sStatus != null)
            {
               m_logger.log (Level.INFO, "Export request current status is : " + sStatus);
            }
         }
      }
      while ((sStatus != null && ("Queued".equals (sStatus) || "In Progress".equals (sStatus))) && numTries < 7);
      if (null != sStatus && "Completed".equalsIgnoreCase (sStatus))
      {
         m_logger.log (Level.INFO, "Export has been successfully completed");
      }
      if (null != sStatus && ("Queued".equalsIgnoreCase (sStatus) || "In Progress".equalsIgnoreCase (sStatus)))
      {
         m_logger.log (Level.INFO, "Export is yet to finish. Monitor service has timed out. Please extract the CSV and retry");
      }
      return sResponse;
   }

   /**
    * Gets the name of the CSV file with export dat to be processed. The input
    * is a Base64 encoded zip file. The zip will be decoded and checked if it
    * contains any csv file. If a csv file is present, the name of the file is 
    * returned or else null.
    *
    * @param sResponse           Response from Retrieve web service as aBase64
    *                            string. The message body is ideally a zip file
    *                            with CSV data file and export summary text
    * @return                    Name of the CSV file with esport data if at all
    *                            present. There can be scenario wherein the
    *                            export request fetches zero records and there
    *                            will be no CSV present inside the zip.
    * @throws MigrationException If specified file is not found or if any file
    *                            IO operation fails
    */
   public String extractCSVFileNameFromResponse (String sResponse)
      throws MigrationException
   {
      byte[] decodedByteArray = DatatypeConverter.parseBase64Binary (sResponse.toString ());
      String sFileName = Util.generateFileName (m_sObjectName);
      sFileName =  Util.getParentPath ()+"\\DataFiles\\" + sFileName + ".zip";
      String sCSVFileName = null;

      try
      {
         BufferedOutputStream bos = new BufferedOutputStream (new FileOutputStream (sFileName, false));
         bos.write (decodedByteArray);
         if (bos != null)
         {
            bos.close ();
         }

         InputStream inputStream = new FileInputStream (sFileName);
         ZipInputStream zStream = new ZipInputStream (inputStream);
         ZipEntry zipEntry;

         byte[] buffer = new byte[8192];
         while ((zipEntry = zStream.getNextEntry ()) != null)
         {
            if (zipEntry.getName ().endsWith (".csv"))
            {

               sCSVFileName =  Util.getParentPath ()+"\\DataFiles\\" + zipEntry.getName ();
               FileOutputStream fos = null;
               try
               {
                  fos = new FileOutputStream (sCSVFileName);
                  int len = 0;
                  while ((len = zStream.read (buffer)) > 0)
                  {
                     fos.write (buffer, 0, len);
                  }
               }
               finally
               {
                  if (inputStream != null)
                  {
                     inputStream.close ();
                  }
                  if (fos != null)
                  {
                     fos.close ();
                  }
                 
               }
               break;
            }
         }
      }
      catch (FileNotFoundException e)
      {
         throw new MigrationException ("Data fetch failed." +sFileName+ " file not found", e);
      }
      catch (IOException e)
      {
         throw new MigrationException ("Data fetch failed. Couldnot read data from zip file" + sFileName,e);
      }
      return sCSVFileName;
   }

   /**
    * Parse any given valid response xml string and fetch the value corresponding
    * to input field name if present.
    *
    * @param sResponse           web service response as string
    * @param sField              Field name for extracting value from response
    * @return                    Value for the field given as input. if field
    *                            not found in respons, error is logged and null
    *                            value is returned
    * @throws  MigrationException
    *           Thrown while parsing FieldResponse xml.
    */
   private String extractFieldDataFromResponse (String sResponse, String sField)
      throws MigrationException
   {
      InputSource source = new InputSource (new StringReader (sResponse));
      XPath xpath = XPathFactory.newInstance ().newXPath ();
      NodeList nodeList;
      String value = null;
      String expression = "//*[local-name()='";
      try
      {
         nodeList = (NodeList)xpath.evaluate (expression + sField + "']", source, XPathConstants.NODESET);
         for (int i = 0; i < nodeList.getLength (); i++)
         {
            value = nodeList.item (i).getFirstChild ().getTextContent ();
         }
      }
      catch (XPathExpressionException e)
      {

         throw new MigrationException("Error parsing response for field: " + sField);
      }
      return value;
   }


   /**
    * Process the user-specified/extracted CSV file and convert the same into a
    * list with format{number ofheaders, header values, data values, number of
    * rows processed}. The output list will have the Eloqua internal field name
    * as key instead of old headers and only data corresponding to fields 
    * specified in mapping file will be processed.
    *
    * @param fieldMappingDef     Mapping between field's CRM display name and
    *                            ELOQUA internal name generated using user-
    *                            provided mapping XML
    * @param sCSVFileName        Name of the CSV file to be processed
    * @param cDeLim              Delimiter to process CSV data file
    * @return                    Processed data as a list with format{number of
    *                            headers, header values, data values, number of
    *                            rows processed}
    * @throws MigrationException If specified CSV cannot be found or any error
    *                            occurs during file IO operations or if there
    *                            is a mismatch between CSV file headers and
    *                            user provided mapping file
    */
   private List<String> processCSVFileUsingFieldMapping (FieldMappingDef fieldMappingDef, String sCSVFileName, char cDeLim)
      throws MigrationException
   {
      List<String> resultList = new ArrayList<String> ();
      List<StringBuilder> tempValues = null;
      List<String> finalValues = new ArrayList<String> ();
      List<StringBuilder> tempArray = null;
      List<Integer> indexes = new ArrayList<Integer> ();
      BufferedReader bufferedReader = null;
      String sCurrLine = "";
      int count = 0;
      String sTemp = "";
      String sNextLine = "";
      try
      {

         bufferedReader =
               new BufferedReader (new InputStreamReader (new FileInputStream (new File (sCSVFileName)), Charset.forName ("UTF-8").newDecoder ()));
         if ((sCurrLine = bufferedReader.readLine ()) != null)
         {
            if (Character.getType (sCurrLine.charAt (0)) == Character.FORMAT)
            {
               sCurrLine = sCurrLine.substring (1);
            }

            if (unMatchedQuotePresent (sCurrLine))
            {
               StringBuilder sb = new StringBuilder (sCurrLine);
               do
               {
                  if ((sNextLine = bufferedReader.readLine ()) != null)
                  {
                     sb.append (sNextLine);
                     sCurrLine = sb.toString ();

                  }
               }
               while (unMatchedQuotePresent (sCurrLine));
            }

            tempValues = Util.split (sCurrLine, cDeLim);
            for (int i = 0; i < tempValues.size (); i++)
            {
               String value = tempValues.get (i).substring (1, tempValues.get (i).length () - 1);
               finalValues.add (i, value);
            }

            List<FieldMapping> mapping = new ArrayList<FieldMapping> ();
            mapping = fieldMappingDef.getMappingList ();
            int index = 0;
            resultList.add (String.valueOf (mapping.size ()));
            for (FieldMapping map : mapping)
            {
               index = finalValues.indexOf (map.getSrcFldDisplayName ());
               if (index < 0)
               {
                  throw new MigrationException ("Source Field Display Name in mapping xml doesnt match with the headers of exported CSV.\n" +
                        "Please run fetchFieldDetailsFromCRMOD and make sure the field display name matches.");
               }
               indexes.add (index);
               resultList.add (map.getTgtIntFldName ());
            }
            tempValues = null;
         }
         while ((sCurrLine = bufferedReader.readLine ()) != null)
         {
            if (unMatchedQuotePresent (sCurrLine))
            {
               StringBuilder sb = new StringBuilder (sCurrLine);
               do
               {
                  if ((sNextLine = bufferedReader.readLine ()) != null)
                  {
                     sb.append ("\n\r").append (sNextLine);
                     sCurrLine = sb.toString ();

                  }
               }
               while (unMatchedQuotePresent (sCurrLine));
            }
            tempArray = Util.split (sCurrLine, cDeLim);

            for (int readIndex : indexes)
            {
               sTemp = tempArray.get (readIndex).toString ();
               resultList.add (sTemp.substring (1, sTemp.length () - 1));
            }
            ++count;
         }
      }
      catch (FileNotFoundException e)
      {
         throw new MigrationException ("Specified CSV not found [" + sCSVFileName + "]", e);
      }
      catch (IOException e)
      {
         throw new MigrationException ("Error in reading the CSV File [" + sCSVFileName + "]", e);
      }
      finally
      {
         if (bufferedReader != null)
         {
            try
            {
               bufferedReader.close ();
            }
            catch (IOException e)
            {
               throw new MigrationException ("Error while closing BufferedReader", e);
            }
         }
      }
      resultList.add (String.valueOf (count));
      return resultList;
   }

   /**
    * Takes the user input values for Export webservice request from
    * command line and prepares a map of key, value pairs for the same. 
    * The optional arguments are default to blank if no input value is present.
    *
    */
   private void prepareExportXMLBindings ()
   {
      String sValue = null;
      String[] optionalArgs =
      { Constants.s_DATE_MOD_BEFORE, Constants.s_DATE_MOD_AFTER, Constants.s_DATE_TIME_FORMAT, Constants.s_TIME_ZONE,
        Constants.s_DELIMITER };

      addUsernameAndPasswdToXMLArgs ();

      for (String key : optionalArgs)
      {
         sValue = CommandLineUtil.getArgumentValue (key);
         if (null != sValue)
         {
            m_xmlArgs.put (key, sValue);
         }
         else
         {
            m_xmlArgs.put (key, "");
         }
      }
     
   }

   /**
    * Checks if there are any unexpected "\n\r" characters present in the current
    * line. If so, the next line is to be appended to the current line and so on
    * till all quotes in the current line are closed.
    *
    * @param  sLine string to check for unmatched quotes
    * @return true if unmatched quote present,else false
    */
   private boolean unMatchedQuotePresent (String sLine)
   {
      boolean bUnmatchedQuote = false;
      for (int i = 0; i < sLine.length (); i++)
      {
         if (sLine.charAt (i) == '"')
         {
            bUnmatchedQuote = !bUnmatchedQuote;
         }
      }
      return bUnmatchedQuote;
   }

   /**
    * Adds CRM username and password to request arguments
    */
   private void addUsernameAndPasswdToXMLArgs ()
   {
      m_xmlArgs.put (Constants.s_CRMOD_USRNAME, CommandLineUtil.getArgumentValue (Constants.s_CRMOD_USRNAME));
      m_xmlArgs.put (Constants.s_CRMOD_PASSWD, CommandLineUtil.getArgumentValue (Constants.s_CRMOD_PASSWD));
   }
}
