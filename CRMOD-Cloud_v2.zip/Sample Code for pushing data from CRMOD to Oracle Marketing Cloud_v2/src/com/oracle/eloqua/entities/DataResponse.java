///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    DataResponse.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author rakraghu
 */
public class DataResponse
   implements IEloquaEntity
{
   @JsonProperty ("uri")
   private String uri;

   public void setUri (String uri)
   {
      this.uri = uri;
   }

   public String getUri ()
   {
      return uri;
   }

   @JsonProperty ("status")
   private String status;

   public void setStatus (String status)
   {
      this.status = status;
   }

   public String getStatus ()
   {
      return status;
   }

   @JsonProperty ("createdBy")
   private String createdby;

   public void setCreatedby (String createdby)
   {
      this.createdby = createdby;
   }

   public String getCreatedby ()
   {
      return createdby;
   }

   @JsonProperty ("syncedInstanceUri")
   private String syncedinstanceuri;

   public void setSyncedinstanceuri (String syncedinstanceuri)
   {
      this.syncedinstanceuri = syncedinstanceuri;
   }

   public String getSyncedinstanceuri ()
   {
      return syncedinstanceuri;
   }

   @JsonProperty ("createdAt")
   private String createdat;

   public void setCreatedat (String createdat)
   {
      this.createdat = createdat;
   }

   public String getCreatedat ()
   {
      return createdat;
   }

}
