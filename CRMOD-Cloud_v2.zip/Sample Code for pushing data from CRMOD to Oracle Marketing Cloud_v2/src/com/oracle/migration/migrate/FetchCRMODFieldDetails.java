///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    FetchCRMODFieldDetails.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.migrate;


import com.oracle.crmod.SoapClient;
import com.oracle.migration.Util.CommandLineUtil;
import com.oracle.migration.Util.Constants;
import com.oracle.migration.Util.Util;
import com.oracle.migration.configurations.ConfigurationReader;
import com.oracle.migration.logging.MigrationLogger;

import java.io.File;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Invokes the field management webservice to read all fields for the specified
 * and their display names in all company enabled languages. The response is
 * formatted and written as xml file. While creating the mapping file, user
 * should specify the display name of the field in user language as the CSV
 * generated via export will contain the same as data headers.
 *
 *@author spalasse
 */
public class FetchCRMODFieldDetails
{
   private static final String s_FIELD_MGMT__WSDL_LOCATION =
      "WSDL/field_mgmt_web_service.xml";
   private static final String s_FIELD_MGMT_SOAP_ACTION =
      "document/urn:crmondemand/ws/odesabs/FieldManagement/:FieldManagementRead";

   public static void main (String[] args)
   {
      ConfigurationReader.loadConfigurations ();
      CommandLineUtil.processCommandLineArgs (args);
      final Logger logger = MigrationLogger.getLogger ();
      String sUsername =
         CommandLineUtil.getArgumentValue (Constants.s_CRMOD_USRNAME);
      String sPasswd =
         CommandLineUtil.getArgumentValue (Constants.s_CRMOD_PASSWD);
      if (null == sUsername || null == sPasswd)
      {
         throw new IllegalStateException ("Required fields CRMOD UserName and CRMOD Password are required arguments");
      }
      String sObjectName =
         CommandLineUtil.getArgumentValue (Constants.s_OBJ_NAME);
      if (null == sObjectName)
      {
         throw new IllegalStateException ("Object name is a required argument");
      }

      Map<String, String> xmlArgs = new HashMap<String, String> ();

      xmlArgs.put ("cu", sUsername);
      xmlArgs.put ("cp", sPasswd);
      xmlArgs.put ("obj", sObjectName);
      String sFileName = Util.generateFileName (sObjectName);
      try
      {
         sFileName =
               Util.getParentPath () + "\\FieldDetails\\CRM\\" + sFileName +
               ".xml";
         String sUrl =
            ConfigurationReader.getConfigurationProperty (Constants.s_CRMODURL);
         if (null == sUrl)
         {
            throw new IllegalStateException ("CRMOD Url cannot be blank");
         }

         SoapClient soapClient =
            new SoapClient (sUrl + "/Services/cte/FieldManagementService");

         if (null != soapClient)
         {
            String status =
               soapClient.sendRequestAndFetchData (s_FIELD_MGMT__WSDL_LOCATION,
                                                   s_FIELD_MGMT_SOAP_ACTION,
                                                   xmlArgs, sFileName);

            if (null != status && status.length () > 0)
            {
               logger.log (Level.INFO,
                           "Field Details are generated at location " +
                           sFileName);
            }
         }
      }
      catch (Exception exception)
      {
         logger.log (Level.SEVERE,
                     "Error occurred while fetching field details from CRMOD",
                     exception);
      }
   }

}
