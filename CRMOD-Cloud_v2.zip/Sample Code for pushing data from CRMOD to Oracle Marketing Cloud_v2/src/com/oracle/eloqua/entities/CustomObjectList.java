///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    CustomObjectList.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author rakraghu
 */
public class CustomObjectList
   implements IEloquaEntity
{
   @JsonProperty ("offset")
   private Integer offset;

   public void setOffset (Integer offset)
   {
      this.offset = offset;
   }

   public Integer getOffset ()
   {
      return offset;
   }

   @JsonProperty ("hasMore")
   private Boolean hasmore;

   public void setHasmore (Boolean hasmore)
   {
      this.hasmore = hasmore;
   }

   public Boolean getHasmore ()
   {
      return hasmore;
   }

   @JsonProperty ("limit")
   private Integer limit;

   public void setLimit (Integer limit)
   {
      this.limit = limit;
   }

   public Integer getLimit ()
   {
      return limit;
   }

   @JsonProperty ("totalResults")
   private Integer totalresults;

   public void setTotalresults (Integer totalresults)
   {
      this.totalresults = totalresults;
   }

   public Integer getTotalresults ()
   {
      return totalresults;
   }

   @JsonProperty ("count")
   private Integer count;

   public void setCount (Integer count)
   {
      this.count = count;
   }

   public Integer getCount ()
   {
      return count;
   }

   @JsonProperty ("items")
   private CustomObjectitemElement[] customobjectitems;

   public void setCustomobjectitems (CustomObjectitemElement[] customobjectitems)
   {
      this.customobjectitems = customobjectitems;
   }

   public CustomObjectitemElement[] getCustomobjectitems ()
   {
      return customobjectitems;
   }

}
