///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    EloquaBulkRestClient.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.httpClient;


import com.oracle.eloqua.entities.IEloquaEntity;
import com.oracle.migration.Util.Constants;
import com.oracle.migration.configurations.ConfigurationReader;
import com.oracle.migration.exceptions.MigrationException;
import com.oracle.migration.logging.MigrationLogger;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URI;
import java.net.URL;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.ClientRequestContext;
import javax.ws.rs.client.ClientRequestFilter;
import javax.ws.rs.client.ClientResponseContext;
import javax.ws.rs.client.ClientResponseFilter;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.HttpUrlConnector;
import org.glassfish.jersey.client.HttpUrlConnector.ConnectionFactory;
import org.glassfish.jersey.client.filter.HttpBasicAuthFilter;
import org.glassfish.jersey.jackson.JacksonFeature;


/**
 * Http Client to Contact Eloqua.
 * Exposes api to send rest request to Eloqua.
 * @author rakraghu
 */
public class EloquaBulkRestClient
{

   final URI m_URI;
   final Client m_client;

   private static final String m_sAPIFilePath = "/API/bulk/2.0";
   private static final List<Integer> m_authErrorStatus =
      new ArrayList<Integer> ();

   static
   {
      m_authErrorStatus.add (301);
      m_authErrorStatus.add (401);
      m_authErrorStatus.add (402);
   }
   private final Logger m_logger = MigrationLogger.getLogger ();


   /**
    * Constructs http client for Eloqua Bulk Import.
    * @param sEloquaInstanceURL
    *       Eloqua URL
    * @param sUserID
    *       Eloqua User ID
    * @param sPassword
    *       Eloqua Password
    * @throws MigrationException
    *       thown while contacting Eloqua
    */
   public EloquaBulkRestClient (String sEloquaInstanceURL, String sUserID,
                                String sPassword)
      throws MigrationException
   {
      if (null == sEloquaInstanceURL || null == sUserID || null == sPassword)
      {
         throw new IllegalStateException ("Eloqua URL, Eloqua User ID and Password are required fields");
      }
      m_URI = createRestEndPointURIFromURL (sEloquaInstanceURL);
      HTTPURLProxyConnectionFactory httpConnFactory =
         new HTTPURLProxyConnectionFactory (ConfigurationReader.getConfigurationProperty (Constants.s_PROXYSERVER),
                                            Integer.valueOf (ConfigurationReader.getConfigurationProperty (Constants.s_PROXYPORT)));

      ClientConfig config = new ClientConfig ();
      HttpUrlConnector connector =
         new HttpUrlConnector (config.getConfiguration (), httpConnFactory);
      config.connector (connector);
      m_client = ClientBuilder.newClient (config);
      m_client.register (new JacksonFeature ());
      m_client.register (new HttpBasicAuthFilter (sUserID, sPassword));
      RestClientLoggingFilter loggingfilter = new RestClientLoggingFilter ();
      m_client.register (loggingfilter);

   }


   /**
    * HTTPMethods Enum for http methods.
    */
   public static enum HTTPMethods
   {
      POST,
      GET,
      PUT,
      DELETE
   };


   /**
    * Creating Rest Endpoint URI for ELoqua
    * @param sURL
    *         Eloqua Instance URL
    * @return
    *       Rest Enpd Point URI
    */
   private URI createRestEndPointURIFromURL (String sURL)
      throws MigrationException
   {
      URI endPointURI = null;
      try
      {
         URL endPointURL = new URL (sURL);
         endPointURI =
               new URL (endPointURL.getProtocol (), endPointURL.getHost (),
                        m_sAPIFilePath).toURI ();
      }
      catch (Exception exception)
      {
         throw new MigrationException ("Error in creating Rest EndPoint URL",
                                       exception);
      }

      return endPointURI;
   }

   /**
    * Returns Builder ready for sending request to restEndpoint.
    * Sets the query params  to bulder.
    * @param sPath
    *        File Path
    * @param pathResolver
    *        Map of Path varible to form rest url.
    * @params queryParams
    *        Map of query params.
    * @return
    *       Invocation Builder.
.
    */
   private Invocation.Builder getInvocationBuilder (String sPath,
                                                    HashMap<String, Object> pathResolver,
                                                    HashMap<String, String> queryParams)
   {
      Invocation.Builder builder;

      WebTarget target = getTarget ().path (sPath);
      if (null != pathResolver && pathResolver.size () != 0)
      {
         target = target.resolveTemplates (pathResolver);
      }

      if (null != queryParams && queryParams.size () != 0)
      {
         for (Entry<String, String> entry : queryParams.entrySet ())
         {
            target =
                  target.queryParam (entry.getKey (), queryParams.get (entry.getKey ()));
         }
      }
      builder = target.request (MediaType.APPLICATION_JSON_TYPE);

      return builder;
   }

   /**
    * Return Webtarget
    * @return WebTarget Object
    */
   private WebTarget getTarget ()
   {
      return m_client.target (m_URI);
   }


   /**
    * Accepts a list of Objects need to inserted to the same path.
    * @param <T>
    * @param method
    *       HTTP Method
    * @param sPath
    *       File Path
    * @param payload
    *       Payload that need to send to OSN
    * @param cls
    *       Return Type Class
    * @param pathResolver
    *       Map contains the values to resolve the path
    * @param queryParam
    *       Map COntains the query params
    * @return
    *       List of inserted IEloquaEntities
    * @throws MigrationException
    *       Logged in user validation,Integration User Validation
    */
   public <T> T sendRequestToEloqua (HTTPMethods method, String sPath,
                                     IEloquaEntity payload, Class<T> cls,
                                     HashMap<String, Object> pathResolver,
                                     HashMap<String, String> queryParam)
      throws MigrationException
   {
      Response response = null;
      Invocation.Builder builder =
         getInvocationBuilder (sPath, pathResolver, queryParam);

      try
      {
         switch (method)
         {
            case POST:
               response = builder.post (Entity.json (payload));
               break;
            case PUT:
               response = builder.put (Entity.json (payload));
               break;
            case GET:
               response = builder.get ();
               break;
            case DELETE:
               response = builder.delete ();
               break;

         }
         if (200 <= response.getStatus () && response.getStatus () <= 204)
         {
            return response.readEntity (cls);
         }
         else if (m_authErrorStatus.contains (response.getStatus ()))
         {
            throw new MigrationException ("Authentication Error: Invalid Eloqua Credentials");
         }
         else
         {
            throw new MigrationException (response.readEntity (String.class));
         }
      }
      finally
      {
         if (null != response)
         {
            response.close ();
         }
      }
   }

   /**
    * Logging Request and response details.
    * @author rakraghu
    *
    */
   private class RestClientLoggingFilter
      implements ClientRequestFilter, ClientResponseFilter
   {

      @Override
      public void filter (ClientRequestContext clientRequestContext)
         throws IOException
      {
         StringBuilder sb = new StringBuilder ();
         ObjectMapper mapper = new ObjectMapper ();
         mapper.enable (SerializationConfig.Feature.INDENT_OUTPUT);
         sb.append ("\n").append ("Request URL :").append (clientRequestContext.getUri ().toString ()).append ("\n")
            .append ("Request Method :").append (clientRequestContext.getMethod ()).append ("\n")
           /* .append ("Request Header :").append (clientRequestContext.getHeaders ().toString ()).append ("\n")*/
            .append ("Request Cookies :").append (clientRequestContext.getCookies ().toString ()).append ("\n")
            .append ("Request Payload :").append (mapper.writeValueAsString (clientRequestContext.getEntity ()));
         m_logger.log (Level.FINE,
                       "RestClientLoggingFilter :  Request sent :[" +
                       sb.toString () + "]");
      }

      @Override
      public void filter (ClientRequestContext clientRequestContext,
                          ClientResponseContext clientResponseContext)
         throws IOException
      {
         StringBuilder sb = new StringBuilder ();
         sb.append ("\n").append ("Response Status :")
            .append (Integer.toString (clientResponseContext.getStatus ())).append ("\n")
            .append ("Response Header :").append (clientResponseContext.getHeaders ().toString ()).append ("\n")
            .append ("Response Cookies :").append (clientResponseContext.getCookies ().toString ()).append ("\n")
            .append ("Response ");
         if (clientResponseContext.hasEntity ())
         {
            clientResponseContext.setEntityStream (logResponseEntity (sb,
                                                                      clientResponseContext.getEntityStream ()));
         }
         m_logger.log (Level.FINE,
                       "RestClientLoggingFilter :  Response received :[ " +
                       sb.toString () + " ]");

      }

      /**
       * Reading the response entity from stream. Once the entity is read the
       * stream should be reset set back to response context.
       *
       * @param sb
       *            string builder
       * @param stream
       *            InputStream
       * @return InputStream
       * @throws IOException
       */
      private InputStream logResponseEntity (StringBuilder sb,
                                             InputStream stream)
         throws IOException
      {
         int maxEntitySize = 10 * 1024;
         if (!stream.markSupported ())
         {
            stream = new BufferedInputStream (stream);
         }
         stream.mark (maxEntitySize + 1);
         byte[] entity = new byte[maxEntitySize + 1];
         int entitySize = stream.read (entity);
         sb.append (new String (entity, 0,
                                Math.min (entitySize, maxEntitySize)));
         if (entitySize > maxEntitySize)
         {
            sb.append ("...more...");
         }
         sb.append ('\n');
         stream.reset ();
         return stream;
      }

   }

   class HTTPURLProxyConnectionFactory
      implements ConnectionFactory
   {

      /**
       * Constructor for creating HTTPURLProxyConnectionFactory
       *
       * @param proxy
       *            Set Proxy instance
       */
      public HTTPURLProxyConnectionFactory (Proxy proxy)
      {
         this.m_Proxy = proxy;
      }

      /**
       * Constructor for creating HTTPURLProxyConnectionFactory
       *
       * @param proxyURL
       *       Proxy URL
       * @param proxyPort
       *       Proxy Port
       */
      public HTTPURLProxyConnectionFactory (String proxyURL, int proxyPort)
      {
         this.m_Proxy =
               new Proxy (Proxy.Type.HTTP, new InetSocketAddress (proxyURL,
                                                                  proxyPort));
      }

      /**
       * Initialises the Proxy object with the proxy setting provided
       *
       * @param proxyURL
       *            URL for the proxy
       * @param proxyPort
       *            port number for the proxy
       */
      public void setHTTPProxy (String proxyURL, int proxyPort)
      {
         m_Proxy =
               new Proxy (Proxy.Type.HTTP, new InetSocketAddress (proxyURL, proxyPort));
      }

      @Override
      public HttpURLConnection getConnection (URL url)
         throws IOException
      {

         HttpURLConnection httpConn;

         if (m_Proxy != Proxy.NO_PROXY)
         {
            httpConn = (HttpURLConnection)url.openConnection (m_Proxy);
         }
         else
         {
            httpConn = (HttpURLConnection)url.openConnection ();
         }

         return httpConn;
      }

      /**
       * Data member
       */
      private Proxy m_Proxy;

   }

   /**
    * Closing the client.
    */
   public void close ()
   {
      m_client.close ();
   }


}
