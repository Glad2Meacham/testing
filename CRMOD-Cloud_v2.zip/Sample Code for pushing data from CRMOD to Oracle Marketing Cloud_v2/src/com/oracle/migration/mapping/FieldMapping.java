///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    FieldMapping.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.mapping;

 /**
  * Reads each mapping from the user specified mapping file and stores the same.
  * Each mapping consists of user entered value for the field in source ad in
  * target application.
  *
  * @author      spalasse
  */
public class FieldMapping
{
   private String srcFldDisplayName;
   private String tgtIntFldName;

   /**
    * Setter for source field name value.
    * 
    * @param srcFldName name of the field in source application
    */
   public void setSrcFldDisplayName (String srcFldName)
   {
      this.srcFldDisplayName = srcFldName;
   }

   /**
    * Getter for source field name value.
    * 
    * @return source field name value in mapping file
    */
   public String getSrcFldDisplayName ()
   {
      return srcFldDisplayName;
   }
   
   /**
    * Setter for target internal field name value.
    * 
    * @param tgtIntFldName name of the field in source application
    */
   public void setTgtIntFldName (String tgtIntFldName)
   {
      this.tgtIntFldName = tgtIntFldName;
   }
   
   /**
    * Getter for target internal field name value.
    * 
    * @return target internal field name in mapping file
    */
   public String getTgtIntFldName ()
   {
      return tgtIntFldName;
   }
}
