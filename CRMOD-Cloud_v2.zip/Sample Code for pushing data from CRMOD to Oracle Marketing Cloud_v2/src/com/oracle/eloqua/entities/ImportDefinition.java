///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    ImportDefinition.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import java.util.Arrays;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;



/**
 * @author rakraghu
 */
@JsonSerialize (include = JsonSerialize.Inclusion.NON_NULL)
public class ImportDefinition
   implements IEloquaEntity
{
   @JsonProperty ("syncActions")
   private Object[] syncactions;

   @JsonProperty ("isUpdatingMultipleMatchedRecords")
   private Boolean isupdatingmultiplematchedrecords;

   @JsonProperty ("uri")
   private String uri;

   @JsonProperty ("updatedBy")
   private String updatedby;

   @JsonProperty ("identifierFieldName")
   private String identifierfieldname;

   @JsonProperty ("updatedAt")
   private String updatedat;

   @JsonProperty ("fields")
   private Fields fields;

   @JsonProperty ("createdBy")
   private String createdby;

   @JsonProperty ("name")
   private String name;

   @JsonProperty ("isSyncTriggeredOnImport")
   private String issynctriggeredonimport;

   @JsonProperty ("createdAt")
   private String createdat;

   public String getCreatedat ()
   {
      return createdat;
   }

   public String getCreatedby ()
   {
      return createdby;
   }

   public Fields getFields ()
   {
      return fields;
   }

   public String getIdentifierfieldname ()
   {
      return identifierfieldname;
   }

   public String getSynctriggeredonimport ()
   {
      return issynctriggeredonimport;
   }

   public Boolean getIsupdatingmultiplematchedrecords ()
   {
      return isupdatingmultiplematchedrecords;
   }

   public String getName ()
   {
      return name;
   }

   public Object[] getSyncactions ()
   {
      return syncactions;
   }

   public String getUpdatedat ()
   {
      return updatedat;
   }

   public String getUpdatedby ()
   {
      return updatedby;
   }

   public String getUri ()
   {
      return uri;
   }

   public void setCreatedat (String createdat)
   {
      this.createdat = createdat;
   }

   public void setCreatedby (String createdby)
   {
      this.createdby = createdby;
   }

   public void setFields (Fields fields)
   {
      this.fields = fields;
   }

   public void setIdentifierfieldname (String identifierfieldname)
   {
      this.identifierfieldname = identifierfieldname;
   }

   public void setIssynctriggeredonimport (String issynctriggeredonimport)
   {
      this.issynctriggeredonimport = issynctriggeredonimport;
   }

   public void setIsupdatingmultiplematchedrecords (Boolean isupdatingmultiplematchedrecords)
   {
      this.isupdatingmultiplematchedrecords = isupdatingmultiplematchedrecords;
   }

   public void setName (String name)
   {
      this.name = name;
   }

   public void setSyncactions (Object[] syncactions)
   {
      this.syncactions = syncactions;
   }

   public void setUpdatedat (String updatedat)
   {
      this.updatedat = updatedat;
   }

   public void setUpdatedby (String updatedby)
   {
      this.updatedby = updatedby;
   }

   public void setUri (String uri)
   {
      this.uri = uri;
   }

   @Override
   public String toString ()
   {
      return "ImportDefinition [syncactions=" + Arrays.toString (syncactions) + ", isupdatingmultiplematchedrecords=" +
         isupdatingmultiplematchedrecords + ", uri=" + uri + ", updatedby=" + updatedby + ", identifierfieldname=" +
         identifierfieldname + ", updatedat=" + updatedat + ", fields=" + fields + ", createdby=" + createdby + ", name=" + name +
         ", issynctriggeredonimport=" + issynctriggeredonimport + ", createdat=" + createdat + "]";
   }

}
