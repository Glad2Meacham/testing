///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    ImportDefinitionList.java
//
///////////////////////////////////////////////////////////////////////////////

package com.oracle.eloqua.entities;

import java.util.Arrays;

import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.map.annotate.JsonSerialize;


@JsonSerialize (include = JsonSerialize.Inclusion.NON_NULL)
/**
 * @author rakraghu
 */
public class ImportDefinitionList
   implements IEloquaEntity
{
   @JsonProperty ("offset")
   private Integer offset;

   public void setOffset (Integer offset)
   {
      this.offset = offset;
   }

   public Integer getOffset ()
   {
      return offset;
   }

   @JsonProperty ("hasMore")
   private Boolean hasmore;

   public void setHasmore (Boolean hasmore)
   {
      this.hasmore = hasmore;
   }

   public Boolean getHasmore ()
   {
      return hasmore;
   }

   @JsonProperty ("limit")
   private Integer limit;

   public void setLimit (Integer limit)
   {
      this.limit = limit;
   }

   public Integer getLimit ()
   {
      return limit;
   }

   @JsonProperty ("totalResults")
   private Integer totalresults;

   public void setTotalresults (Integer totalresults)
   {
      this.totalresults = totalresults;
   }

   public Integer getTotalresults ()
   {
      return totalresults;
   }

   @JsonProperty ("count")
   private Integer count;

   public void setCount (Integer count)
   {
      this.count = count;
   }

   public Integer getCount ()
   {
      return count;
   }

   @JsonProperty ("items")
   private ImportDefinition[] items;

   public void setItems (ImportDefinition[] items)
   {
      this.items = items;
   }

   public ImportDefinition[] getItems ()
   {
      return items;
   }

   @Override
   public String toString ()
   {
      return "ImportDefinitionList [offset=" + offset + ", hasmore=" + hasmore + ", limit=" + limit + ", totalresults=" +
         totalresults + ", count=" + count + ", items=" + Arrays.toString (items) + "]";
   }

}
