///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    DataItems.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;


import com.oracle.eloqua.serializer.DataSerializer;

import java.util.LinkedHashMap;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


/**
 * DataItems has Eloqua InternalFieldName as key and corresponding data as value for import.
 * InternalFieldNames differs accross CustomObjects.
 * This bean alsr requires Custom Serializer.
 * @author rakraghu
 */
@JsonSerialize (using = DataSerializer.class, include = Inclusion.NON_NULL)

public class DataItems
   implements IEloquaEntity
{

   Map<String, String> dataItem = new LinkedHashMap<String, String> ();

   public Map<String, String> getDataItem ()
   {
      return dataItem;
   }

   public void putDataItem (String key, String value)
   {
      this.dataItem.put (key, value);
   }

}
