///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    FieldMapping.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.mapping;

import java.util.List;

/**
 * Data structure to store all the field mappings from the user specified
 * mapping file. A FieldMappingDef is made up of a source application type,
 * a target application type, name of object in source, name of the object in
 * target and list of field mappings. Each fieldmapping maps a field in source
 * to its corresponding field in target
 *
 * @author      spalasse
 */
public class FieldMappingDef
{
   private String sourceType;
   private String targetType;
   private String sourceObjectName;
   private String targetObjectName;
   private List<FieldMapping> mappingList;

   /**
    * Sets source application type
    * 
    * @param sourceType
    */
   public void setSourceType (String sourceType)
   {
      this.sourceType = sourceType;
   }

   /**
    * Gets source application type
    * 
    * @return source application type
    */
   public String getSourceType ()
   {
      return sourceType;
   }
   
   /**
    * Sets target application type
    * 
    * @param targetType
    */
   public void setTargetType (String targetType)
   {
      this.targetType = targetType;
   }

   /**
    * Gets target application type
    * 
    * @return target application type
    */
   public String getTargetType ()
   {
      return targetType;
   }

   /**
    * Sets the field mapping between source and target
    * 
    * @param mappingList List of all field mappings specified in maping file.
    */
   public void setMappingList (List<FieldMapping> mappingList)
   {
      this.mappingList = mappingList;
   }

   /**
    * Gets list of all field mappings specified
    * 
    * @return List of all field mappings specified in maping file.
    */
   public List<FieldMapping> getMappingList ()
   {
      return mappingList;
   }

   /**
    * Sets the name of the object in source application
    * 
    * @param sourceObjectName name of the object in source application
    */
   public void setSourceObjectName (String sourceObjectName)
   {
      this.sourceObjectName = sourceObjectName;
   }

   /**
    * Gets the name of the object in source application
    * 
    * @return name of the object in source application
    */
   public String getSourceObjectName ()
   {
      return sourceObjectName;
   }

   /**
    * Sets the name of the object in target application
    * 
    * @param targetObjectName name of the object in target application
    */
   public void setTargetObjectName (String targetObjectName)
   {
      this.targetObjectName = targetObjectName;
   }

   /**
    * Gets the name of the object in target application
    * 
    * @return name of the object in target application
    */
   public String getTargetObjectName ()
   {
      return targetObjectName;
   }
}
