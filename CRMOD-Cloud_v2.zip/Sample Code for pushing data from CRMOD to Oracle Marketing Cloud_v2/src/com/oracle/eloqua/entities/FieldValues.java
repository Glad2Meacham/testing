///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    FieldValues.java
//
///////////////////////////////////////////////////////////////////////////////

package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;
/**
 * @author rakraghu
 */
public class FieldValues
{
   @JsonProperty ("Name1")
   private String name1;

   public void setName1 (String name1)
   {
      this.name1 = name1;
   }

   public String getName1 ()
   {
      return name1;
   }

   @JsonProperty ("Currency1")
   private String currency1;

   public void setCurrency1 (String currency1)
   {
      this.currency1 = currency1;
   }

   public String getCurrency1 ()
   {
      return currency1;
   }

}
