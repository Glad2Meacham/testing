///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    CustomObjectitemElement.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import org.codehaus.jackson.annotate.JsonProperty;

/**
 * @author rakraghu
 */
public class CustomObjectitemElement
{
   @JsonProperty ("emailAddressFieldUri")
   private String emailaddressfielduri;

   public void setEmailaddressfielduri (String emailaddressfielduri)
   {
      this.emailaddressfielduri = emailaddressfielduri;
   }

   public String getEmailaddressfielduri ()
   {
      return emailaddressfielduri;
   }

   @JsonProperty ("uri")
   private String uri;

   public void setUri (String uri)
   {
      this.uri = uri;
   }

   public String getUri ()
   {
      return uri;
   }

   @JsonProperty ("updatedBy")
   private String updatedby;

   public void setUpdatedby (String updatedby)
   {
      this.updatedby = updatedby;
   }

   public String getUpdatedby ()
   {
      return updatedby;
   }

   @JsonProperty ("updatedAt")
   private String updatedat;

   public void setUpdatedat (String updatedat)
   {
      this.updatedat = updatedat;
   }

   public String getUpdatedat ()
   {
      return updatedat;
   }

   @JsonProperty ("displayNameFieldUri")
   private String displaynamefielduri;

   public void setDisplaynamefielduri (String displaynamefielduri)
   {
      this.displaynamefielduri = displaynamefielduri;
   }

   public String getDisplaynamefielduri ()
   {
      return displaynamefielduri;
   }

   @JsonProperty ("createdBy")
   private String createdby;

   public void setCreatedby (String createdby)
   {
      this.createdby = createdby;
   }

   public String getCreatedby ()
   {
      return createdby;
   }

   @JsonProperty ("name")
   private String name;

   public void setName (String name)
   {
      this.name = name;
   }

   public String getName ()
   {
      return name;
   }

   @JsonProperty ("createdAt")
   private String createdat;

   public void setCreatedat (String createdat)
   {
      this.createdat = createdat;
   }

   public String getCreatedat ()
   {
      return createdat;
   }

   @JsonProperty ("uniqueFieldUri")
   private String uniqueFieldUri;

   public void setUniqueFieldUri (String uniqueFieldUri)
   {
      this.uniqueFieldUri = uniqueFieldUri;
   }

   public String getUniqueFieldUri ()
   {
      return uniqueFieldUri;
   }

}
