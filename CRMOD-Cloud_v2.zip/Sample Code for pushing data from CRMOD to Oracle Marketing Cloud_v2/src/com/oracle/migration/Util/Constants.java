///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    Constants.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.Util;

/**
 * Holds constants used across classes 
 *
 *@author spalasse
 */
public class Constants
{
   public static final String s_CRMOD_USRNAME = "cu";
   public static final String s_CRMOD_PASSWD = "cp";
   public static final String s_ELOQ_USRNAME = "eu";
   public static final String s_ELOQ_PASSWD = "ep";
   public static final String s_DATE_MOD_BEFORE = "db";
   public static final String s_DATE_MOD_AFTER = "da";
   public static final String s_TIME_ZONE = "tz";
   public static final String s_DATE_TIME_FORMAT = "df";
   public static final String s_DELIMITER = "dl";
   public static final String s_OBJ_NAME = "obj";
   public static final String s_CSVFILENAME = "csv";
   public static final String s_MAPPINGFILE = "mf";
   public static final String s_CRMODURL = "crmodurl";
   public static final String s_ELOQURL = "eloquaurl";
   public static final String s_PROXYSERVER = "proxyServer";
   public static final String s_PROXYPORT = "proxyPort";
   public static final String s_CHUNKSIZE = "chunkSize";
}
