///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2015, Oracle Corporation, All rights reserved.
//
//  FILE
//    DataItemList.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;

import com.oracle.eloqua.serializer.DataListSerializer;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


/**
 * @author rakraghu
 *
 */
@JsonSerialize (using = DataListSerializer.class, include = Inclusion.NON_NULL)
public class DataItemList
   implements IEloquaEntity
{

   DataItems[] datalist;
   @JsonIgnore
   ArrayList<DataItems> lstArrayData = new ArrayList<DataItems> ();


   public void addDataItem (DataItems dataItem)
   {
      lstArrayData.add (dataItem);
   }

   public DataItems[] getDataItemList ()
   {
      convertArrayLIsttoDataArray (lstArrayData);
      return datalist;
   }

   private void convertArrayLIsttoDataArray (List<DataItems> lstData)
   {
      DataItems[] arrData = new DataItems[lstData.size ()];
      datalist = lstData.toArray (arrData);

   }

}
