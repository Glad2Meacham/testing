///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    CommandLineUtil.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.Util;

import java.util.HashMap;
import java.util.Map;

/**
 * Util class to read command line args and store the argument-value pairs
 * as map entries to be accessed across application
 *
 *@author spalasse
 */
public class CommandLineUtil
{
   private static final Map<String, String> arguments = new HashMap<String, String> ();


   /**
    * Reads all the command line arguments in "key:value" format and generates
    * the map of the same.
    * 
    * @param args Array of command line arguments
    */
   public static void processCommandLineArgs (String[] args)
   {
      char delim = ':';
      String key ;
      String val ;
      for (String argument : args)
      {
         key = argument.substring (1, argument.indexOf (delim));
         val = argument.substring (argument.indexOf (delim) + 1);
         arguments.put(key, val);
      }
   }

   /**
    * Returns value for any command line argument if provided  by user,
    * else returns null
    * 
    * @param sArg
    * @return
    *    Returns Argument Value
    */
   public static String getArgumentValue (String sArg)
   {
      return arguments.get(sArg);
   }
}
