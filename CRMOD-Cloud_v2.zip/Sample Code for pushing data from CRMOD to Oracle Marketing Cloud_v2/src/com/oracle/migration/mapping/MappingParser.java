///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    MappingParser.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.mapping;


import com.oracle.migration.Util.Util;
import com.oracle.migration.exceptions.MigrationException;

import java.io.FileInputStream;
import java.io.InputStream;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 * SAX parser to parse the mapping file and generate
 * corresponding field mapping definition between CRM
 * display name and ELOQUA internal name
 *
 *@author spalasse
 */
public class MappingParser
   extends DefaultHandler
{

   private static FieldMappingDef m_fieldMappingDef;
   private FieldMapping m_fieldMapping;
   private List<FieldMapping> m_fieldMappingList = new ArrayList<FieldMapping> ();
   private String m_sTemp;


   /**
    * Creates a SAX parser instance and reads the user proided mapping file and 
    * generates a FieldMappingDef object from it. The FieldMappingDef inturn
    * contains all the field mappings between source and target and will be used
    * to process data fetched from source and map the same to correspondig
    * fields in target appliction.
    * 
    * @param fileName            Name of the mapping file specified as command-
    *                            line argument
    * @return                    Field Mapping definition between source and 
    *                            target appication fields for the object 
    *                            generated after parsing the mapping file
    * @throws MigrationException if mapping file cannot be found or error occurs 
    *                            while parsing the mapping file  
    */
   public static FieldMappingDef createFieldmappingDef (String fileName)
      throws MigrationException
   {
      SAXParser parser = null;
      InputStream stream = null;
      try
      {
         parser = SAXParserFactory.newInstance ().newSAXParser ();
         MappingParser parseXml = new MappingParser ();
         stream = new FileInputStream (Util.getParentPath ()+"\\Mapping\\" + fileName);
         parser.parse (stream, parseXml);
      }
      catch (Exception e)
      {
         throw new MigrationException ("Error in Parsing mapping file: " + fileName, e);
      }
      return m_fieldMappingDef;
   }

   @Override
   public void characters (char[] buffer, int start, int length)
   {
      m_sTemp = new String (buffer, start, length);
   }

   @Override
   public void startElement (String uri, String localName, String element, Attributes attributes)
      throws SAXException
   {
      m_sTemp = "";
      if (element.equalsIgnoreCase ("mappingdef"))
      {
         m_fieldMappingDef = new FieldMappingDef ();
         m_fieldMappingDef.setSourceType (attributes.getValue ("srcType"));
         m_fieldMappingDef.setTargetType (attributes.getValue ("tgtType"));

      }
      else if (element.equalsIgnoreCase ("sourceobject"))
      {
         m_fieldMappingDef.setSourceObjectName (attributes.getValue ("name"));
      }
      else if (element.equalsIgnoreCase ("targetobject"))
      {
         m_fieldMappingDef.setTargetObjectName (attributes.getValue ("name"));
      }
      else if (element.equalsIgnoreCase ("fieldMapping"))
      {
         m_fieldMapping = new FieldMapping ();
         m_fieldMapping.setSrcFldDisplayName (attributes.getValue ("srcFldDisplayName"));
         m_fieldMapping.setTgtIntFldName (attributes.getValue ("tgtIntFldName"));
         m_fieldMappingList.add (m_fieldMapping);
      }
   }

   @Override
   public void endElement (String uri, String localName, String element)
      throws SAXException
   {
      if (element.equalsIgnoreCase ("mappings"))
      {
         m_fieldMappingDef.setMappingList (m_fieldMappingList);

      }
   }
}


