///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    MigrationException.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.migration.exceptions;

/**
 * Migration Releated Exceptions
 * @author rakraghu
 *
 */
public class MigrationException
   extends Exception
{

   /**
    * Constructs new MigrationException
    * @param message 
    *       Error Message
    */
   public MigrationException (String message)
   {
      super (message);
     
   }

   /**
    * Constructs new MigrationException with Throwable cause.
    * @param message
    *       Error message
    * @param cause
    *       Exception to be stacked.
    */
   public MigrationException (String message, Throwable cause)
   {
      super (message, cause);
     
   }



}
