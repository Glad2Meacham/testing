///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    Fields.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.eloqua.entities;


import com.oracle.eloqua.serializer.FieldsDeserialzer;
import com.oracle.eloqua.serializer.FieldsSerializer;

import java.util.LinkedHashMap;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonDeserialize;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;


/**
 * Fields differs from Custom obejcts.
 * All fields for Eloqua Imports are store as a key value pair,
 * where field intenal name is the key and value is corresponding statement for it.
 * E.g �"First_Name1": "{{CustomObject[41].Field[219]}}"
 * Serializing and de-serializing the field details requires custom serializers
 * @author rakraghu
 */
@JsonSerialize (using = FieldsSerializer.class, include = Inclusion.NON_NULL)
@JsonDeserialize (using = FieldsDeserialzer.class)
public class Fields
   implements IEloquaEntity
{

   Map<String, String> fieldMap = new LinkedHashMap<String, String> ();

   public Map<String, String> getFieldMap ()
   {
      return fieldMap;
   }

   public void setField (String key, String value)
   {
      this.fieldMap.put (key, value);
   }

   @Override
   public String toString ()
   {
      return "Fields [fieldMap=" + fieldMap + "]";
   }

}
