
///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    FetchEloquaFieldDetails.java
//
///////////////////////////////////////////////////////////////////////////////

package com.oracle.migration.migrate;


import com.oracle.eloqua.entities.CustomObjectList;
import com.oracle.eloqua.entities.CustomObjectitemElement;
import com.oracle.eloqua.entities.FieldDetails;
import com.oracle.eloqua.httpClient.EloquaBulkRestClient;
import com.oracle.migration.Util.CommandLineUtil;
import com.oracle.migration.Util.Constants;
import com.oracle.migration.Util.Util;
import com.oracle.migration.configurations.ConfigurationReader;
import com.oracle.migration.exceptions.MigrationException;
import com.oracle.migration.logging.MigrationLogger;

import java.io.File;

import java.net.URLDecoder;

import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;


/**
 * Fetches Field Details for the specified Custom Object and written in to file under FieldDetails\ELOQUA folder.
 *
 * @author rakraghu
 */
public final class FetchEloquaFieldDetails
{
   private final static String s_ELOQUAURL = "eloquaurl";
   private final String m_sEloquaObjectName;
   private final EloquaBulkRestClient m_client;
   private CustomObjectList m_CustomObjectList;
   private FieldDetails m_fldDetails;
   private final static HashMap<String, String> queryParam;
   static
   {
      queryParam = new HashMap<String, String> ();
      queryParam.put ("format", "json");
   }

   /**
    * Constructs FetchEloquaFieldDetails Object.Creats an instance http client.
    * @param sEloquaObjectName 
    *       Eloqua Custom Object Name
    * @param sEloquaUserId 
    *       Eloqua UserID
    * @param sEloquaPassword
    *       Eloqua Password
    * @throws MigrationException
    *       thrown while contacting eloqua.
    */
   public FetchEloquaFieldDetails (String sEloquaObjectName, String sEloquaUserId, String sEloquaPassword)
      throws MigrationException
   {
      super ();
      this.m_sEloquaObjectName = sEloquaObjectName;
      String sEloquaURL = ConfigurationReader.getConfigurationProperty (s_ELOQUAURL);
      m_client = new EloquaBulkRestClient (sEloquaURL, sEloquaUserId, sEloquaPassword);
   }

   /**
    * Fetches all Eloqua Custom Obeject to find the URI for the desired object.
    * @throws MigrationException
    *       thrown while connecting to eloqua.
    */
   private void fectchEloquaCustomObejcts ()
      throws MigrationException
   {
      String customObjectsPath = "customObjects";
      m_CustomObjectList =
            m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, customObjectsPath, null, CustomObjectList.class,
                                          null, queryParam);
      fetchFieldDetailsForEloquaCustomObject (getEloquaObjectURI ());

   }

   /**
    * Closing the client
    */
   public void close ()
   {
      if (null != m_client)
      {
         m_client.close ();
      }
   }

   /**
    * Fetched field details for the Custom Object.
    * @param sEloquaCustomObjectURI
    *       Custom Object URL
    * @throws MigrationException
    *       thrown while contacting eloqua.
    *
    */
   private void fetchFieldDetailsForEloquaCustomObject (String sEloquaCustomObjectURI)
      throws MigrationException
   {
      String sEloquaCOFieldDetailsPath = "{customObjectURL}/fields";
      HashMap<String, Object> pathResolver = new HashMap<String, Object> ();
      pathResolver.put ("customObjectURL", sEloquaCustomObjectURI);

      m_fldDetails =
            m_client.sendRequestToEloqua (com.oracle.eloqua.httpClient.EloquaBulkRestClient.HTTPMethods.GET, sEloquaCOFieldDetailsPath, null, FieldDetails.class,
                                          pathResolver, queryParam);
   }

   /**
    * Return the Custom Object URI from custom Object list
    * @return  
    *       Custom Object URI
    * @throws MigrationException
    *       throwm if the custom Object is not present.
    */   
   private String getEloquaObjectURI ()
      throws MigrationException
   {
      CustomObjectitemElement desiredItem = null;
      for (CustomObjectitemElement item : m_CustomObjectList.getCustomobjectitems ())
      {
         if (m_sEloquaObjectName.equals (item.getName ()))
         {
            desiredItem = item;
            break;
         }


      }
      if (desiredItem == null)
      {
         throw new MigrationException (m_sEloquaObjectName + " does not exist in Eloqua");
      }
      return desiredItem.getUri ();
   }

   public static void main (String[] args)
   {

      ConfigurationReader.loadConfigurations ();
      final Logger logger = MigrationLogger.getLogger ();
      CommandLineUtil.processCommandLineArgs (args);
      String sObjectName = CommandLineUtil.getArgumentValue (Constants.s_OBJ_NAME);
      if (null == sObjectName)
      {
         throw new IllegalStateException ("Eloqua Custom Object Name is required field");
      }
      FetchEloquaFieldDetails fetchEloquaFieldDetails = null;

      try
      {
         fetchEloquaFieldDetails =
               new FetchEloquaFieldDetails (sObjectName, CommandLineUtil.getArgumentValue (Constants.s_ELOQ_USRNAME),
                                            CommandLineUtil.getArgumentValue (Constants.s_ELOQ_PASSWD));
         fetchEloquaFieldDetails.fectchEloquaCustomObejcts ();

         File jarPath = new File (ConfigurationReader.class.getProtectionDomain ().getCodeSource ().getLocation ().getPath ());
         String sParentPath = jarPath.getParentFile ().getAbsolutePath ();
         String fileNname = Util.generateFileName (fetchEloquaFieldDetails.getEloquaObjectName ());
         File fieldFile =
            new File (URLDecoder.decode (sParentPath + "\\FieldDetails\\ELOQUA\\" + fileNname + ".txt", "UTF-8"));
         ObjectMapper mapper = new ObjectMapper ();
         mapper.enable (SerializationConfig.Feature.INDENT_OUTPUT);
         mapper.writeValue (fieldFile, fetchEloquaFieldDetails.getFldDetails ());
         logger.log (Level.INFO, "File Created " + fieldFile.getAbsolutePath ());

      }
      catch (Exception e)
      {
         logger.log (Level.SEVERE, "Error occurred while fetching " + sObjectName + "  field details from Eloqua", e);
      }
      finally
      {
         if (null != fetchEloquaFieldDetails)
            fetchEloquaFieldDetails.close ();
      }

   }

   /**
    * Returns Eloqua Object name
    * @return
    *       Eloqua Object Name
    */
   public String getEloquaObjectName ()
   {
      return m_sEloquaObjectName;
   }

   /**
    * Return thr Field Details.
    * @return
    *    FieldDetails object.
    */
   public FieldDetails getFldDetails ()
   {
      return m_fldDetails;
   }
}
