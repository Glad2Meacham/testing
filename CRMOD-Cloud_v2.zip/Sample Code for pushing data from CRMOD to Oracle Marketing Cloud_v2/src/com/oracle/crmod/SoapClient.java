///////////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2014, Oracle Corporation, All rights reserved.
//
//  FILE
//    SoapClient.java
//
///////////////////////////////////////////////////////////////////////////////
package com.oracle.crmod;


import com.oracle.migration.Util.Constants;
import com.oracle.migration.configurations.ConfigurationReader;
import com.oracle.migration.exceptions.MigrationException;
import com.oracle.migration.logging.MigrationLogger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;

import java.net.Inet6Address;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.URL;

import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.net.ssl.HttpsURLConnection;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;


/**
 * Creates SOAP connection to CRM OD instance url using user-provided
 * authentication, prepares the request from input WSDL file, invokes the web
 * service and collects the response.
 *
 * @author      spalasse
 */
public class SoapClient
{
   //request parameter string constants
   private final static String s_REQUEST_METHOD = "POST";
   private final static String s_CONTENT_TYPE_NAME = "Content-Type";
   private final static String s_CONTENT_LENGTH_NAME = "Content-Length";
   private final static String s_SOAP_ACTION_NAME = "SOAPAction";
   private final static String s_CONTENT_TYPE_VALUE = "text/xml; charset=utf-8";

   private URL m_endPointURL;
   private final Logger m_logger = MigrationLogger.getLogger ();


   /**
    * Constructor that formats and connects to given input URL.
    * @param sUrl CRM OD instance URL provided in config.properties
    * @throws MigrationException
    *          Thrown when URL is malformed.
    */
   public SoapClient (String sUrl)


      throws MigrationException
   {
      if (sUrl != null && sUrl.length () > 0)
      {
         try
         {
            m_endPointURL = new URL (sUrl);
         }
         catch (MalformedURLException e)
         {
            throw new MigrationException("URL "+sUrl+" is not well formed", e);      
         }
      }
   }


   /**
    * Prepares the request and invokes the specified action using webservice API 
    * based on input WSDL. Response received is converted to string format
    * 
    * @param sWSDLLocation       location of the WSDL file for the web service    
    * @param soapAction          SOAP action to be invoked at end point URL
    * @param xmlArgs             Web servic request parameters and values as map
    * @return                    Web service response formatted as string
    * @throws MigrationException If connection CRM OD instance gives an error                         
    */
   public String sendRequestAndFetchData (String sWSDLLocation, String soapAction, Map<String, String> xmlArgs)
      throws MigrationException
   {
      HttpsURLConnection httpsURLConnection = null;
      String sResult = null;
      try
      {
         httpsURLConnection = initConnection ();
         String sReqStr = prepareRequest (sWSDLLocation, xmlArgs);
         connectToURL (soapAction, httpsURLConnection, sReqStr);

         sResult = readDataFromConnection (httpsURLConnection, sReqStr);
      }
      catch (Exception e)
      {
         throw new MigrationException ("Couldnot connect to URL. Please check connection parameters", e);
      }
      finally
      {
         httpsURLConnection.disconnect ();
      }
      return sResult;
   }

   /**
    * Prepares the request and invokes the specified action using webservice API
    * based on input WSDL. Response received is written into specified file
    *
    * @param sWSDLLocation 
    *       location of the WSDL file for the web service
    * @param soapAction 
    *       SOAP action to be invoked at end point URL
    * @param xmlArgs 
    *       Web servic request parameters and values as map
    * @param sFileName 
    *       Name of the file response data is written into
    * @return success 
    *       if data written into file successfully
    * @throws MigrationException
    *       thrown while contacting CRMOD
    */
   public String sendRequestAndFetchData (String sWSDLLocation, String soapAction, Map<String, String> xmlArgs, String sFileName)


      throws MigrationException
   {
      HttpsURLConnection httpsURLConnection = null;
      String sResultString = null;
      try
      {
         // create connection
         httpsURLConnection = initConnection ();
         String sReqStr = prepareRequest (sWSDLLocation, xmlArgs);
         connectToURL (soapAction, httpsURLConnection, sReqStr);
         if (null != sFileName)
         {
            try
            {
               sResultString = readDataAndWriteToFile (httpsURLConnection, sReqStr, sFileName);
            }
            catch (IOException e)
            {
               if (null != xmlArgs.get (Constants.s_OBJ_NAME))
               {
                  throw new IllegalStateException ("Invalid object name :" + xmlArgs.get (Constants.s_OBJ_NAME) +
                                                   "or incorrect request parameters");
               }
               else
               {
                  throw new IllegalStateException ("Invalid object name :");
               }
            }

         }
      }
      catch (Exception e)
      {
         throw new MigrationException("Error creating field details", e);
      }
      finally
      {
         if (httpsURLConnection != null)
         {
            httpsURLConnection.disconnect ();
         }
      }
      return sResultString;
   }

   /**
    * Connects CRM instance URL using given request parameters and soap action
    * 
    * @param soapAction SOAP action to be executed at end point URL
    * @param httpsURLConnection connection instance 
    * @param sReqStr web service request in string format
    * @throws MigrationException if connection to end point URL fails
    */
   private void connectToURL (String soapAction, HttpsURLConnection httpsURLConnection, String sReqStr)
      throws MigrationException
   {
      int len = sReqStr.length ();
      httpsURLConnection.setRequestProperty (s_CONTENT_LENGTH_NAME, Integer.toString (len));
      httpsURLConnection.setRequestProperty (s_SOAP_ACTION_NAME, setSoapAction (soapAction));
      try
      {
         httpsURLConnection.connect ();
      }
      catch (IOException e)
      {
         throw new MigrationException ("Connection attempt failed",e);
      }
   }

   /**
    * Connects to end point URL output stream using the connection instance.
    * Data is processed in "UTF-8" encoding and converted into corresponding
    * string format
    * 
    * @param httpsURLConnection            htpps connection instance
    * @param sReqStr                       web service request in String format
    * @return                              web service response in String format
    * @throws UnsupportedEncodingException If "UTF-8" encoding is not supported 
    *                                      by stream
    * @throws IOException                  If connection IO operation errors out
    */
   private String readDataFromConnection (HttpsURLConnection httpsURLConnection, String sReqStr)
      throws UnsupportedEncodingException, IOException
   {
      StringBuilder sb = new StringBuilder ();
      InputStreamReader read = null;
      OutputStreamWriter out = new OutputStreamWriter (httpsURLConnection.getOutputStream (), "UTF-8");
      out.write (sReqStr, 0, sReqStr.length ());
      out.flush ();
      if (out != null)
      {
         out.close ();
      }
      read = new InputStreamReader (httpsURLConnection.getInputStream (), "UTF-8");
      int ch = read.read ();
      while (ch != -1)
      {
         sb.append ((char)ch);
         ch = read.read ();
      }
      if (read != null)
      {
         read.close ();
      }
      return sb.toString ();
   }


   /**
    * Creates the underlying https connection to end point URL. If proxy is
    * specified in config.properties, proxy will be set as well.
    * 
    * @return                    the HTTPS connection object
    * @throws MigrationException if connection to end point URL fails
    */
   private HttpsURLConnection initConnection ()
      throws MigrationException
   {
      HttpsURLConnection httpsURLConnection = null;
      String sProxyServer = ConfigurationReader.getConfigurationProperty (Constants.s_PROXYSERVER);
      String sProxyPort = ConfigurationReader.getConfigurationProperty (Constants.s_PROXYPORT);

      Proxy httpProxy=null;
      if (null != sProxyServer && null != sProxyPort)
      {
         httpProxy = new Proxy(Proxy.Type.HTTP,new InetSocketAddress(sProxyServer,Integer.valueOf (sProxyPort)));
      }

      try
      {
         if (Proxy.NO_PROXY != httpProxy)
         {
            httpsURLConnection =
                  (HttpsURLConnection)this.m_endPointURL.openConnection (httpProxy);
         }
         else
         {
            httpsURLConnection =
                  (HttpsURLConnection)this.m_endPointURL.openConnection ();
         }
      }
      catch (IOException e)
      {
         throw new MigrationException ("Error connecting to URL.", e);
      }
      try
      {
         httpsURLConnection.setRequestMethod (s_REQUEST_METHOD);
      }
      catch (ProtocolException e)
      {
         throw new MigrationException ("HTTPS Connection error.", e);
      }
      httpsURLConnection.setDoOutput (true);
      httpsURLConnection.setDoInput (true);
      httpsURLConnection.setRequestProperty (s_CONTENT_TYPE_NAME, s_CONTENT_TYPE_VALUE);
      return httpsURLConnection;
   }
   /**
    * Reads the WSDL file, converts into a string and replaces all template
    * keys with corresponding values from user input valuesstored in xmlArgs
    *
    * @param sWSDLLocation       Location of WSDL file to read
    * @param xmlArgs             XML template arguments and values as map
    * @return                    webservice request in String format
    * @throws MigrationException if file IO operation errors out
    */
   private String prepareRequest (String sWSDLLocation, Map<String, String> xmlArgs)
      throws MigrationException
   {
      StringBuilder sbBuff;
      boolean readFlag = false;
      String sInputXml = null;
      BufferedReader br = null;
      if (!readFlag)
      {
         sbBuff = new StringBuilder ();
         try
         {
            InputStream in = getClass ().getClassLoader ().getResourceAsStream (sWSDLLocation);
            br = new BufferedReader (new InputStreamReader (in));
            String line = "";
            while ((line = br.readLine ()) != null)
            {
               sbBuff.append (line);
            }
         }
         catch (IOException e)
         {
            throw new MigrationException ("Error parsing WSDL" ,e);
         }

         finally
         {
            if (br != null)
            {
               try
               {
                  br.close ();
               }
               catch (IOException e)
               {
                  throw new MigrationException ("Error parsing WSDL :",e);
               }
            }
         }
         sInputXml = sbBuff.toString ();
         readFlag = true;
      }
      String arg = "";
      for (Iterator i = xmlArgs.keySet ().iterator (); i.hasNext (); )
      {
         arg = (String)i.next ();
         if (arg != null)
         {
            sInputXml = sInputXml.replace (">" + arg + "<", ">" + xmlArgs.get (arg) + "<");
         }
      }
      m_logger.log (Level.INFO, "Request string prepared : " + sInputXml);
      return sInputXml;
   }

  /**
    * Formats the SOAP action string
    * 
    * @param soapAction          unformatted SOAP action string
    * @return                    formatted SOAP action string
    * @throws MigrationException if SOAP action is not valid
    */
   private String setSoapAction (String soapAction)
      throws MigrationException
   {
      if (soapAction.endsWith ("\"") && soapAction.startsWith ("\""))
      {

      }
      else if (!soapAction.endsWith ("\"") && !soapAction.startsWith ("\""))
      {
         soapAction = "\"" + soapAction + "\"";
      }
      else
      {
         throw new MigrationException ("SOAP action is not valid");
      }

      return soapAction;
   }

   /**
    * Connects to end point URL output stream using the connection instance.
    * Data is processed in "UTF-8" encoding and written as formatted string
    * into specified file.
    *
    * @param httpsURLConnection           htpps connection instance
    * @param sReqStr                       web service request in String format
    * @param fileName                      file name to write xml data into
    * @return                              "success" if formatted web service 
    *                                      response succesfully written
    * @throws UnsupportedEncodingException If "UTF-8" encoding is not supported
    *                                      by stream
    * @throws IOException                  If connection IO operation errors out
    * @throws MigrationException           If output xml formatting errors out
    */
   private String readDataAndWriteToFile (HttpsURLConnection httpsURLConnection, String sReqStr, String fileName)
      throws UnsupportedEncodingException, IOException, MigrationException
   {
      BufferedWriter stringWriter = null;
      OutputStreamWriter out = null;
      try
      {
         out = new OutputStreamWriter (httpsURLConnection.getOutputStream (), "UTF-8");
         out.write (sReqStr, 0, sReqStr.length ());
         out.flush ();

         Source xmlInput = new StreamSource (new InputStreamReader (httpsURLConnection.getInputStream (), "UTF-8"));
         stringWriter = new BufferedWriter (new OutputStreamWriter (new FileOutputStream (fileName), "UTF-8"));
         StreamResult xmlOutput = new StreamResult (stringWriter);
         TransformerFactory transformerFactory = TransformerFactory.newInstance ();
         transformerFactory.setAttribute ("indent-number", 2);
         Transformer transformer = transformerFactory.newTransformer ();
         transformer.setOutputProperty (OutputKeys.INDENT, "yes");
         transformer.transform (xmlInput, xmlOutput);
         stringWriter.write (xmlOutput.getWriter ().toString ());
         stringWriter.close ();

      }
      catch (Exception e)
      {
         throw new MigrationException ("Error in formatting output xml", e);
      }
      finally
      {
         if (out != null)
         {
            out.close ();
         }
         if (stringWriter != null)
         {
            stringWriter.close ();
         }
      }
      return "success";
   }

   /**
    * Return the logger instance.
    * 
    * @return logger insance
    */
   public Logger getLogger ()
   {
      return m_logger;
   }
}
